public class Scooter {

}
