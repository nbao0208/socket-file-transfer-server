public interface Vehicle {
    //default method
    //constant --> example: double SPEED_RATE = 9 --> it's a constant
    //abstract method
    float getCurrentSpeed(int amount);

    void move(float speed);

    void sound();

    void breakSpeed(float speed);

    default void starting() {
        System.out.println("Brun brun brun!!!");
    }
}
