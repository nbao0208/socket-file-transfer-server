import java.util.Objects;

public class Car implements Vehicle {
    String manufacturer;
    double price;

    CarType type;
    float speed;

    public Car(String manufacturer, double price, CarType type, float speed) {
        this.manufacturer = manufacturer;
        this.price = price;
        this.type = type;
        this.speed = speed;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public CarType getType() {
        return type;
    }

    public void setType(CarType type) {
        this.type = type;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }

    @Override
    public String toString() {
        return "Car{" +
                "manufacturer='" + manufacturer + '\'' +
                ", price=" + price +
                ", type=" + type +
                ", speed=" + speed +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Car car = (Car) o;
        return Double.compare(price, car.price) == 0 && Float.compare(speed, car.speed) == 0 && Objects.equals(manufacturer, car.manufacturer) && type == car.type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(manufacturer, price, type, speed);
    }

    @Override
    public float getCurrentSpeed(int amount) {
        return this.speed;
    }

    @Override
    public void move(float speed) {
        this.speed += speed;
    }

    @Override
    public void sound() {
        System.out.println("Car bruh bruh");
    }

    @Override
    public void breakSpeed(float speed) {
        if (speed > this.speed) {
            System.out.println("Cannot break the car with this speed");
            return;
        }
        this.speed -= speed;
    }
}
