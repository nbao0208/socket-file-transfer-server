public class Bicycle {
}
