public enum CarType {
    ELECTRIC,
    PETROL
}
