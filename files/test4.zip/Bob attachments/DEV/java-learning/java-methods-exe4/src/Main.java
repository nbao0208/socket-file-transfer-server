public class Main {
    public static void main(String[] args) {
        theResult(2, 2);
    }

    static void theResult(int n1, int n2) {
        String result;
        if (n1 == n2) {
            result = "The numbers are equal";
        } else {
            result = n1 > n2 ? "The first number is larger" : "The second number is larger";
        }
        System.out.println(result);
    }
}