import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int MonthlyRent = 0;
        int OriginalPriceOfProperty = 0;
        System.out.println("Your monthly rental income: ");
        MonthlyRent = scanner.nextInt();
        System.out.println("You purchased the property for: ");
        OriginalPriceOfProperty = scanner.nextInt();
        System.out.println("Your rental yield is: " + String.format("%.2f", rentalYield(MonthlyRent, OriginalPriceOfProperty)) + "%");
    }

    static float rentalYield(int MonthlyRent, int OriginalPriceOfProperty) {
        return ((float) (12 * MonthlyRent) / (float) OriginalPriceOfProperty) * 100;
    }
}