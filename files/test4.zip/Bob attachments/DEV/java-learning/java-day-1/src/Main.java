import student.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        List<Student> myStudent = new ArrayList<>();
        int limit;
        System.out.println("Write the number of the student: ");
        //same like cout in c++ but need to be defined
        Scanner sc = new Scanner(System.in);
        limit = sc.nextInt();
        while (limit <= 0) {
            System.out.println("Again: ");
            limit = sc.nextInt();
        }
        for (int i = 0; i < limit; i++) {
            String name;
            String dob;
            int age;
            System.out.println("What is your name: ");
            sc.nextLine();
            name = sc.nextLine();
            System.out.println("What is your dob: ");
            dob = sc.nextLine();
            System.out.println("How old are you: ");
            age = sc.nextInt();
            Student temp = new Student(name, dob, age);
            myStudent.add(temp);
        }
        int count = 1;
        for (Student i : myStudent) {
            System.out.println("Student " + count);
            System.out.println("Name: " + i.getName());
            System.out.println("Dob: " + i.getDob());
            System.out.println("Age: " + i.getAge());
            count++;
        }
        System.out.println("============THANKS============");
    }
}