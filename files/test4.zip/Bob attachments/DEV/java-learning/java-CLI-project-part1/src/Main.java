import Models.User;
import Service.CarBookingService;
import Service.CarService;
import Service.UserService;
import Service.UserServiceImplementation;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean flag = true;
        User user = new User();
        while (flag) {
            System.out.println("1\uFE0F⃣ - Register");
            System.out.println("2\uFE0F⃣ - Book Car");
            System.out.println("3\uFE0F⃣ - View All User Booked Cars");
            System.out.println("4\uFE0F⃣ - View All Bookings");
            System.out.println("5\uFE0F⃣ - View Available Cars");
            System.out.println("6\uFE0F⃣ - View Available Electric Cars");
            System.out.println("7\uFE0F⃣ - View all users");
            System.out.println("8\uFE0F⃣ - Exit");
            switch (scanner.nextInt()) {
                case 1: {
                    try {
                        user = (new UserServiceImplementation()).userRegister();
                    } catch (IOException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                }
                case 2: {
                    if (user.equals(new User())) {
                        System.out.println("Please register before booking");
                    } else {
                        try {
                            while (true) {
                                boolean isAccess = CarBookingService.bookCar(user);
                                if (isAccess) {
                                    (new UserServiceImplementation()).addInfoOfCarBooked(user);
                                    System.out.println("Register successfully");
                                    break;
                                } else {
                                    System.out.println("Cannot find car's register number, please do again");
                                }
                            }
                        } catch (IOException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    break;
                }
                case 3: {
                    if (user.equals(new User())) {
                        System.out.println("Please register before booking");
                    } else {
                        try {
                            (new UserServiceImplementation()).viewAllUserBookedCar();
                        } catch (FileNotFoundException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    break;
                }
                case 4: {
                    if (user.equals(new User())) {
                        System.out.println("Please register before booking");
                    } else {
                        try {
                            CarBookingService.viewAllBooking();
                        } catch (FileNotFoundException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    break;
                }
                case 5: {
                    if (user.equals(new User())) {
                        System.out.println("Please register before booking");
                    } else {
                        try {
                            CarService.viewAllAvailableCar();
                        } catch (FileNotFoundException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    break;
                }
                case 6: {
                    if (user.equals(new User())) {
                        System.out.println("Please register before booking");
                    } else {
                        try {
                            CarService.viewAvailableElectricCar();
                        } catch (FileNotFoundException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    break;
                }
                case 7: {
                    if (user.equals(new User())) {
                        System.out.println("Please register before booking");
                    } else {
                        try {
                            (new UserServiceImplementation()).viewAllUser();
                        } catch (FileNotFoundException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                    break;
                }
                case 8: {
                    flag = false;
                    break;
                }
                default: {
                    System.out.println("Don't exist this choice");
                }
            }
        }
        System.out.println("Thanks for your coming ❤\uFE0F");
    }
}