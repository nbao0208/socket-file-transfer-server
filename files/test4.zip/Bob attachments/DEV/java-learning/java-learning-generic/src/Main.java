import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Map<Integer, Person> persons = new HashMap<>();
        persons.put(1, new Person("John", 18));
        persons.put(2, new Person("Bao", 18));
        persons.put(3, new Person("Norris", 23));
        persons.forEach((number, person) -> {
            System.out.println(number + " " + person);
        });

        System.out.println();
        Box<Phone> boxForPhone = new Box<>();
        Box<Laptop> boxForLaptop = new Box<>();
        List<Laptop> laptops = new ArrayList<>();
        List<Phone> phones = new ArrayList<>();

        laptops.add(new Laptop("Apple"));
        laptops.add(new Laptop("Dell"));
        phones.add(new Phone("Apple"));
        phones.add(new Phone("Samsung"));
        boxForPhone.setItems(phones);
        boxForLaptop.setItems(laptops);
        for (Phone item : boxForPhone.getItems()) {
            System.out.println(item);
        }
        System.out.println();
        boxForLaptop.getItems().forEach((System.out::println));

        Integer[] numbers = {1, 2, 3, 4, 5};
        Double[] doubleNumbers = {1.2, 2.3, 3.4, 4.5};
        System.out.println(countGreaterThan(numbers, 2));
        System.out.println(countGreaterThan(doubleNumbers, 3.1));
    }

    record Person(String name, int age) {
    }

    // the Type T must implement the interface or extend the class --> if it's ok, it'll work
    static <T extends Comparable<T>> int countGreaterThan(T[] numbers, T number) {
        int count = 0;
        for (T n : numbers) {
            if (n.compareTo(number) > 0) {
                count++;
            }
        }
        return count;
    }
}