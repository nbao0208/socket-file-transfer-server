public class Passport {
    String name;

    Dob dob;
    String country;
    String countryID;

    Passport(String name, Dob dob, String country, String countryID) {
        this.name = name;
        this.dob = dob;
        this.country = country;
        this.countryID = countryID;
    }

    Passport() {
        this.name = null;
        this.country = null;
        this.countryID = null;
        this.dob = new Dob();
    }
}
