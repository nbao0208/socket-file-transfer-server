import com.sun.security.jgss.GSSUtil;

import java.time.LocalDate;
import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Passport BaoPassport = new Passport("Nguyen Dinh Quoc Bao", new Dob(2, 8, 2005), "Viet Nam", "1827639263");
        Passport ChrisPassport = new Passport("Dang Ngoc Thien Kim Christyna", new Dob(2, 7, 2007), "Viet Nam", "127491726912");
        Passport userPassport = new Passport();
        System.out.println("Nhap thong tin khach hang moi: ");
        addPassportInfo(userPassport);
        System.out.println("Khach hang chuan bi bay: ");
        printPassport(BaoPassport);
        System.out.println();
        printPassport(ChrisPassport);
        System.out.println();
        printPassport(userPassport);
    }

    public static void printPassport(Passport user) {
        System.out.println("Name: " + user.name);
        System.out.println("Day of birth: " + user.dob.day + "/" + user.dob.month + "/" + user.dob.year);
        System.out.println("Country: " + user.country);
        System.out.println("Country's ID: " + user.countryID);
    }

    public static int countAppearance(int[] a, int target) {
        int count = 0;
        for (int value : a) {
            if (value == target) {
                count++;
            }
        }
        return count;
    }

    public static void addDob(Dob dob) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Day: ");
        dob.day = scanner.nextInt();
        System.out.println("Month: ");
        dob.month = scanner.nextInt();
        System.out.println("Year: ");
        dob.year = scanner.nextInt();
    }

    public static void addPassportInfo(Passport user) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("What is user's name: ");
        user.name = scanner.nextLine();
        System.out.println("What is user's day of birth: ");
        addDob(user.dob);
        System.out.println("What is user's country: ");
        user.country = scanner.nextLine();
        System.out.println("What is user's ID: ");
        user.countryID = scanner.nextLine();
    }
}