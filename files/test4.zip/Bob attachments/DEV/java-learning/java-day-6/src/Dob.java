public class Dob {
    int day;
    int month;
    int year;

    Dob(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    Dob() {
        this.day = 0;
        this.month = 0;
        this.year = 0;
    }
}
