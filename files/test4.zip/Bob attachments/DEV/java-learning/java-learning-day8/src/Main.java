import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char grade;
        System.out.println("Write the rank of student : ");
        grade = scanner.next().charAt(0);
        String result = switch (grade) {
            case 'A' -> "Excellent";
            case 'B', 'C' -> "Pass";
            default -> "Fail";
        };
        System.out.println("Result: " + result);
    }
}