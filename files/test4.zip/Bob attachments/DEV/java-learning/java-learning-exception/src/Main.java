public class Main {
    public static void main(String[] args) {
        try {
            System.out.println(factorial(-1));
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("Almost run!!!!");
    }

    // sth throws exception meaning that methods might have this exception
    // the users can fix or not, and the system will stop when the exception acting
    // Let the exception this method had to the place invoked this method fix
    static int factorial(int n) throws IllegalArgumentException {
        if (n < 0) {
            // if happen the exception, it will throw a line say the error
            throw new IllegalArgumentException("Cannot factory negative number");
        }
        if (n == 0) {
            return 1;
        }
        return n * factorial(n - 1);
    }

    //Nên để cái nơi mà gọi cái hàm mà có ngoại lệ xử lý ngoại lệ đó, nên là hay để throws exception
    // trong hàm và để nơi gọi nó xử lý ngoại lệ bằng khối try-catch
}