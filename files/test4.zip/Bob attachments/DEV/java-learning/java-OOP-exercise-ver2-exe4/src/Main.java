import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Questionnaire questionnaire = new Questionnaire();
        questionnaire.setActionForQuestionnaire(new ActionForQuestionnaire());
        questionnaire.setQuestions(questionnaire.getActionForQuestionnaire().createNewFile("src/questions.csv"));
        questionnaire.setUserAnswers(questionnaire.getActionForQuestionnaire().createNewFile("src/userAnswers.csv"));
        List<String> userAnswers = answers(questionnaire.getQuestions());
        questionnaire.getActionForQuestionnaire().writeToFile(questionnaire.getUserAnswers(), userAnswers);
        questionnaire.getActionForQuestionnaire().printAnswers(questionnaire.getQuestions(), questionnaire.getUserAnswers());
    }

    static List<String> answers(File questions) {
        try {
            List<String> result = new ArrayList<>();
            Scanner scanner = new Scanner(System.in);
            Scanner scannerForQuestions = new Scanner(questions);
            while (scannerForQuestions.hasNext()) {
                System.out.println(scannerForQuestions.nextLine());
                result.add(scanner.nextLine());
            }
            return result;
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}