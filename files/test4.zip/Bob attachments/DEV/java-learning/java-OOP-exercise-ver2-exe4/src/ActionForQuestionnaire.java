import java.io.*;
import java.util.List;
import java.util.Scanner;

public class ActionForQuestionnaire {
    public File createNewFile(String path) {
        File file = new File(path);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return file;
    }

    public void writeToFile(File file, String answer) {
        try (FileWriter fileWriter = new FileWriter(file);
             PrintWriter info = new PrintWriter(fileWriter, true)) {
            info.println(answer);
            info.println("Bao xam lon");
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    public void writeToFile(File file, List<String> answers) {
        try (FileWriter fileWriter = new FileWriter(file, true);
             BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
            for (String answer : answers) {
                bufferedWriter.newLine();
                bufferedWriter.write(answer);
            }
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }

    }

    public void printAnswers(File questions, File answers) {
        try {
            Scanner scanner1 = new Scanner(questions);
            Scanner scanner2 = new Scanner(answers);
            while (scanner1.hasNext() && scanner2.hasNext()) {
                System.out.println(scanner1.nextLine());
                System.out.println(scanner2.nextLine());
                System.out.println();
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    public ActionForQuestionnaire() {
    }


}
