import java.io.File;
import java.util.List;

public class Questionnaire {
    private File questions;
    private File userAnswers;
    private ActionForQuestionnaire actionForQuestionnaire;

    public Questionnaire(File questions, File userAnswers) {
        this.questions = questions;
        this.userAnswers = userAnswers;
    }

    public Questionnaire(File questions, File userAnswers, ActionForQuestionnaire actionForQuestionnaire) {
        this.questions = questions;
        this.userAnswers = userAnswers;
        this.actionForQuestionnaire = actionForQuestionnaire;
    }

    public Questionnaire() {
    }

    public ActionForQuestionnaire getActionForQuestionnaire() {
        return actionForQuestionnaire;
    }

    public void setActionForQuestionnaire(ActionForQuestionnaire actionForQuestionnaire) {
        this.actionForQuestionnaire = actionForQuestionnaire;
    }

    public File getQuestions() {
        return questions;
    }

    public void setQuestions(File questions) {
        this.questions = questions;
    }

    public File getUserAnswers() {
        return userAnswers;
    }

    public void setUserAnswers(File userAnswers) {
        this.userAnswers = userAnswers;
    }
}
