public class Main {
    public static void main(String[] args) {
        for (TShirtSize tShirtSize : TShirtSize.values()) {
            System.out.printf(tShirtSize.name().toLowerCase() + " ");
        }
    }
}