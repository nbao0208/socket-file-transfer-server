public class Main {
    public static void main(String[] args) {
        String[] arr = {"123", "1343"};
        System.out.println("The array's size: " + getSize(arr));
    }

    static int getSize(String[] arr) {
        return arr.length;
    }
}