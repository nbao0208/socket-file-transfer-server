public class Main {
    public static void main(String[] args) {
        System.out.println(areTheSame(1, 1));
    }

    static boolean areTheSame(int n1, int n2) {
        return n1 == n2;
    }
}