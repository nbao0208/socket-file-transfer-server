import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        File file = createFile("src/test.txt");
        writeToFile(file);
        try {
            // scanner seam like a pointer for line in the file so that is control the line in the file
            // so this can be print our line or our info in the file
            Scanner scanner = new Scanner(file);
            while (scanner.hasNext()) {
                System.out.println(scanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }

    }

    private static File createFile(String path) {
        try {
            File file = new File(path);
            if (!file.exists()) {
                file.createNewFile();
            }
            return file;
        } catch (IOException e) {
            System.out.println(e.getMessage());
            throw new IllegalArgumentException(e);
        }
    }

    private static void writeToFile(File file) {


        try {
            FileWriter fileWriter = new FileWriter(file);
            PrintWriter writer = new PrintWriter(fileWriter);
            writer.println("Hello World!!");
            writer.println("I want to say that I love Christyna^^!!!!");
            writer.flush();
            writer.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}