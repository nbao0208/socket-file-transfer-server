import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String sentence;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Write the sentence: ");
        sentence = scanner.nextLine();
        System.out.println("The word of the sentence is: " + numberOfWord(sentence));
    }

    static int numberOfWord(String sentence) {
        //Hàm split(string that to substring) sẽ trả về một arr gồm các từ được cắt bởi một từ phân tách nào đó
        String[] word = sentence.split(" ");
        return word.length;
    }
}