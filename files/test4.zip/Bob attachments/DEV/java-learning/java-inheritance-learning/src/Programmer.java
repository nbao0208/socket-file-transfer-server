import java.util.Arrays;

public class Programmer extends Employee {
    String[] languagesProgram;

    public Programmer(String name, int age, String experience, String address, String[] languagesProgram) {
        super(name, age, experience, address);
        this.languagesProgram = languagesProgram;
    }

    @Override
    public void sayHi() {
        System.out.println("Hello mate!!!");
    }

    @Override
    public String toString() {
        return "Programmer{" +
                " name='" + name + '\'' +
                ", age=" + age +
                ", experience='" + experience + '\'' +
                ", address='" + address + '\'' +
                ",languagesProgram=" + Arrays.toString(languagesProgram) +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Programmer that = (Programmer) o;
        return Arrays.equals(languagesProgram, that.languagesProgram);
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + Arrays.hashCode(languagesProgram);
        return result;
    }
}
