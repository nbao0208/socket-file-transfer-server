public class Main {
    public static void main(String[] args) {
        String[] languages = {"Java", "GoLang"};
        Employee programmer = new Programmer("James", 20, "Backend", "USA", languages);
        System.out.println(programmer);
        programmer.sayHi();
    }
}