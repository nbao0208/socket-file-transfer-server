public class Main {
    public static void main(String[] args) {
        Cat rose1 = new Cat("Rose", 2, "Blue");
        Cat rose2 = new Cat("Rose", 2, "Blue");

        Cat[] cats = {rose1, rose2};
        Person Bao = new Person("Nguyen", "Bao", Gender.MALE, cats);
        System.out.println(Bao);
    }
}