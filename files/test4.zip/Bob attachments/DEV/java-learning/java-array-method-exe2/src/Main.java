import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String followingString;
        System.out.println("Write your following string: ");
        followingString = scanner.nextLine();
        System.out.println("Following word: " + followingString);
        System.out.println("Suggested word: " + suggestedString(followingString));
    }

    static String suggestedString(String string) {
        String result = "";
        for (int i = 0; i < string.length(); i++) {
            if (string.charAt(i) != ' ') {
                result = result.concat(Character.toString(string.charAt(i)));
            }
        }
        return result.substring(0, 1).toUpperCase() + result.substring(1);
    }

}