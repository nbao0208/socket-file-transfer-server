import java.util.ArrayList;
import java.util.List;

public class Main {
    //Exercise 1
    public static void main(String[] args) {
        int sum = 0;
        List<String> argCannotConverted = new ArrayList<>();
        for (String arg : args) {
            try {
                sum += Integer.parseInt(arg);
            } catch (NumberFormatException e) {
                argCannotConverted.add(arg);
            }
        }
        System.out.println(sum);
        for (String str : argCannotConverted) {
            System.out.printf(str + " ");
        }
        System.out.printf("are not int numbers");
    }

}