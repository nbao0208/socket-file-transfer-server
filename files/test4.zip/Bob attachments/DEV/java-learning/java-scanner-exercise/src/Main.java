import java.util.Random;
import java.util.Scanner;

public class Main {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        char ans;
        do {
            int exe = 0;
            System.out.println("exe?");
            exe = scanner.nextInt();
            switch (exe) {
                case 1: {
                    Exe1();
                    break;
                }
                case 2: {
                    Exe2(args);
                    break;
                }
                case 3: {
                    Exe3();
                    break;
                }
                case 4: {
                    Exe4();
                    break;
                }
                default: {
                    System.out.println("Don't exist");
                }
            }
            System.out.println("Do you want to watch more: ");
            ans = scanner.next().charAt(0);
        } while (ans == 'y');
    }

    static void Exe1() {
        String sth;
        System.out.println("Write sth: ");
        sth = scanner.next();
        System.out.println(sth.toUpperCase());
    }

    static void Exe2(String[] args) {
        for (String arg : args) {
            System.out.println(Integer.parseInt(arg));
        }
    }

    static void Exe3() {
        int number = 0;
        System.out.println("Write the number: ");
        number = scanner.nextInt();
        if (isPrime(number)) {
            System.out.println(number + " is Prime");
        } else {
            System.out.println(number + " is not Prime");
        }
    }

    static void Exe4() {
        String[] jokes = {"haha", "hahahahahhaha", "hahahahahahaha"};
        Random random = new Random();
        String ans;
        do {
            int randomIndex = random.nextInt(2);
            System.out.println(jokes[randomIndex]);
            System.out.println("Want to hear a joke: ");
            ans = scanner.next();
        } while (ans.equalsIgnoreCase("Yes"));
    }

    static boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        if (n == 2 || n == 3) {
            return true;
        }
        if (n % 2 == 0) {
            return false;
        }
        for (int i = 3; i < n; i += 2) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}