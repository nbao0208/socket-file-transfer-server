public class Main {
    public static void main(String[] args) {
        String string = "Hello World!!";
        System.out.println(reverseString(string));
    }

    static String reverseString(String string) {
        String reversedString = "";
        for (int i = string.length() - 1; i >= 0; i--) {
            reversedString = reversedString + string.charAt(i);
        }
        return reversedString;
    }
}