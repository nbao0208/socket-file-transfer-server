import Object.*;

import java.io.IOException;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        User user = new User();
        Questionnaire questionnaire = new Questionnaire();
        try {
            questionnaire.setQuestions(QuestionnaireUtility.createNewFile("src/questions.csv"));
            questionnaire.setAnswers(QuestionnaireUtility.createNewFile("src/data.csv"));

            Scanner scanner = new Scanner(System.in);
            System.out.println("What is your first name: ");
            user.setFirstName(scanner.nextLine());
            System.out.println("What is your last name: ");
            user.setLastName(scanner.nextLine());
            System.out.println("This is the Q&A about your cat sir/ma'am");

            QuestionnaireUtility.takeAnswer(user, questionnaire.getQuestions());

            QuestionnaireUtility.writeToFile(questionnaire.getAnswers(), user);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("Thanks sir/ma'am");
    }
}