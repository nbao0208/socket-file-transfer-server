public class Main {
    public static void main(String[] args) {
        System.out.println(theRightWord("bao"));
    }

    static String theRightWord(String string) {
        return string.substring(0, 1).toUpperCase() + string.substring(1);
    }
}