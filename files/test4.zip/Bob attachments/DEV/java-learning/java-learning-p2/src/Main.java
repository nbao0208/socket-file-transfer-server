import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        if (args.length > 0) {
            System.out.println(Arrays.toString(args));
        } else {
            System.out.println("0 argument");
        }
    }
}
