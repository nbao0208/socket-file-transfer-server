import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        String[] strings = {"hello", "bingo", "ola", "bye", "ciao"};
        List<String> longestWord = new ArrayList<>(LongestWord(strings));
        for (String string : longestWord) {
            System.out.printf(string + " ");
        }
    }

    static List<String> LongestWord(String[] strings) {
        int maxLength = strings[0].length();
        for (int i = 1; i < strings.length; i++) {
            if (strings[i].length() > maxLength) {
                maxLength = strings[i].length();
            }
        }
        List<String> result = new ArrayList<>();
        for (int i = 0; i < strings.length; i++) {
            if (strings[i].length() == maxLength) {
                result.add(strings[i]);
            }
        }
        // một Set có thể lọc ra các phần tử duy nhất từ một List, các phần tử đó sẽ không trùng nhau
        return new ArrayList<>(new HashSet<>(result));
    }
}