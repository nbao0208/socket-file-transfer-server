public class Main {
    public static void main(String[] args) {
        //--> any reference in Java when declare is same like declare pointer in C++
        // --> we need object __ = new object()
        Student Bao = new Student("Bao", "12CT1");
        Student Chris = new Student("Christyna", "11CP");
        Student QuocBao = Bao;
        System.out.println("Before change: ");
        Bao.printInfo();
        Chris.printInfo();
        QuocBao.printInfo();

        QuocBao.name = "Quoc Bao";
        QuocBao.studentClass = "CLC_CNTT";
        System.out.println("After change: ");
        Bao.printInfo();
        Chris.printInfo();
        QuocBao.printInfo();
        // --> All reference are same like pointer in C++
        // -->if reference A = reference B --> same like A pointer to B and anything changes in A, so B will be change similarly
    }

    static class Student {
        String name;
        String studentClass;

        Student(String name, String studentClass) {
            this.name = name;
            this.studentClass = studentClass;
        }

        public void printInfo() {
            System.out.println(name);
            System.out.println(studentClass);
        }

    }
}