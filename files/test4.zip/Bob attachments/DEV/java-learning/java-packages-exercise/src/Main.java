import email.EmailValidator;
import email.EmailValidator.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.println(new EmailValidator().isAnEmail("nbao0208@gmail.com"));

    }
}