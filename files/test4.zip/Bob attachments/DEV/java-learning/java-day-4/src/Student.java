

public class Student {
    String name;
    String studentClass;
    Dob dob;
    int age;

    Student(String name, String studentClass, Dob dob, int age) {
        this.name = name;
        this.studentClass = studentClass;
        this.dob = dob;
        this.age = age;
    }
}
