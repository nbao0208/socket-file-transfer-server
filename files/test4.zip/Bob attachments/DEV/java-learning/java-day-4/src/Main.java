import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Student QuocBao = new Student("Nguyen Dinh Quoc Bao", "12CT1", new Dob(2, 8, 2005), 18);
        Student Christyna = new Student("Dang Ngoc Thien Kim Christyna", "11CP", new Dob(2, 7, 2007), 16);
        String choice;
        Scanner sc = new Scanner(System.in);
        System.out.println("Write your way you want to see Chris and Bao: ");
        choice = sc.nextLine();
        switch (choice) {
            case "One": {
                System.out.println("They have married^^");
                break;
            }
            case "Two": {
                System.out.println("They have married too:))))^^");
                break;
            }
            default: {
                System.out.println("They only have to be married^^");
                break;
            }
        }
    }
}