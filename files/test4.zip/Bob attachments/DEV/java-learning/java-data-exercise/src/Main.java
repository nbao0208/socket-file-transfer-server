import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        LocalDateTime time = LocalDateTime.now();
        System.out.println(time);
        Scanner scanner = new Scanner(System.in);
        LocalDate dob;
        // format the string of date
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String date;
        System.out.println("Your day of brith: ");
        date = scanner.next();
        // get the string and transform to a date with a formatter
        dob = LocalDate.parse(date, formatter);
        System.out.println(dob);
        System.out.println(dob.plusDays(100));
        System.out.println("Your age is " + (LocalDate.now().getYear() - dob.getYear()));

    }
}