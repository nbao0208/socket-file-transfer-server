

import java.time.LocalDateTime;
import java.time.ZoneId;

public class Main {
    public static void main(String[] args) {
        for (String zone : ZoneId.getAvailableZoneIds()) {
            System.out.println(zone);
        }
        LocalDateTime timeInEurope = LocalDateTime.now(ZoneId.of("Europe/Monaco"));
        System.out.println(timeInEurope);
    }


}