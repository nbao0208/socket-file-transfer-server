public class CarService {
    public void carWashed(Car car) {
        System.out.println(car.getOwnerName() + "'s car is washing!!!!");
    }

    public void CarMaintenance(Car car) {
        System.out.println(car.getOwnerName() + "'s car is being maintained");
    }

    public CarService() {
    }

}
