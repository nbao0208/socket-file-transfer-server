import java.util.Objects;

public class Car {
    private String manufacturer;
    private double price;
    private CarType carType;

    private String ownerName;

    public Car() {
    }

    public Car(String manufacturer, double price, CarType carType) {
        this.manufacturer = manufacturer;
        this.price = price;
        this.carType = carType;
    }

    public Car(String manufacturer, double price, CarType carType, String ownerName) {
        this.manufacturer = manufacturer;
        this.price = price;
        this.carType = carType;
        this.ownerName = ownerName;
    }

    public void unUn() {
        System.out.println("UNUNNNNNN");
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public CarType getCarType() {
        return carType;
    }

    public void setCarType(CarType carType) {
        this.carType = carType;
    }

    @Override
    public String toString() {
        return "Car{" +
                "manufacturer='" + manufacturer + '\'' +
                ", price=" + price +
                ", carType=" + carType +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Car car = (Car) o;
        return Double.compare(price, car.price) == 0 && Objects.equals(manufacturer, car.manufacturer) && carType == car.carType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(manufacturer, price, carType);
    }
}
