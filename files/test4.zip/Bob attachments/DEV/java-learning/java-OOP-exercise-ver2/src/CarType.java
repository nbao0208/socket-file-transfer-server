public enum CarType {
    PETROL,
    ELECTRIC,
    RUN_BY_RICE
}
