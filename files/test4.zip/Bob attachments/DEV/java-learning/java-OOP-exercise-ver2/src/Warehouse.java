import java.util.List;
import java.util.Objects;

public class Warehouse {
    private double areaSize;
    private List<Car> cars;

    public Warehouse() {
    }

    public Warehouse(double areaSize, List<Car> cars) {
        this.areaSize = areaSize;
        this.cars = cars;
    }

    public double getAreaSize() {
        return areaSize;
    }

    public void setAreaSize(double areaSize) {
        this.areaSize = areaSize;
    }

    public List<Car> getCars() {
        return cars;
    }

    public void setCars(List<Car> cars) {
        this.cars = cars;
    }

    @Override
    public String toString() {
        return "Warehouse{" +
                "areaSize=" + areaSize +
                ", cars=" + cars +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Warehouse warehouse = (Warehouse) o;
        return Double.compare(areaSize, warehouse.areaSize) == 0 && Objects.equals(cars, warehouse.cars);
    }

    @Override
    public int hashCode() {
        return Objects.hash(areaSize, cars);
    }
}
