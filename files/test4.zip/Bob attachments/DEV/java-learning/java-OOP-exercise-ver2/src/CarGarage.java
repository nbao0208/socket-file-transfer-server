import java.util.List;
import java.util.Objects;

public class CarGarage {
    private String name;
    private String Location;
    private CarService carService;
    private Warehouse warehouse;

    public CarGarage(String name, String location, CarService carService, Warehouse warehouse) {
        this.name = name;
        Location = location;
        this.carService = carService;
        this.warehouse = warehouse;
    }


    public CarGarage() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public CarService getCarService() {
        return carService;
    }

    public void setCarService(CarService carService) {
        this.carService = carService;
    }

    public Warehouse getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(Warehouse warehouse) {
        this.warehouse = warehouse;
    }

    @Override
    public String toString() {
        return "CarGarage{" +
                "name='" + name + '\'' +
                ", Location='" + Location +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CarGarage carGarage = (CarGarage) o;
        return Objects.equals(name, carGarage.name) && Objects.equals(Location, carGarage.Location) && Objects.equals(carService, carGarage.carService) && Objects.equals(warehouse, carGarage.warehouse);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, Location, carService, warehouse);
    }
}
