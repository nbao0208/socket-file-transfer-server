import java.util.ArrayList;
import java.util.List;

public class Exercise3 {
    public static void main(String[] args) {
        CarGarage carGarage = new CarGarage("Bao's Garage House", "12345 district 5 HCM", new CarService(), new Warehouse());
        List<Car> cars = new ArrayList<>();
        cars.add(new Car("Mec", 9999.99, CarType.PETROL, "BaoNguyen"));
        cars.add(new Car("Rollroyce", 9999999.99, CarType.PETROL, "Christyna"));
        cars.add(new Car("Tesla", 9999.99, CarType.ELECTRIC, "NorrisNguyen"));
        carGarage.setWarehouse(new Warehouse(12345, cars));
        carGarage.getCarService().carWashed(carGarage.getWarehouse().getCars().get(0));
        carGarage.getCarService().CarMaintenance(carGarage.getWarehouse().getCars().get(2));
        System.out.println(carGarage);
    }
}
