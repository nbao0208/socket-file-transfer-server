import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        File file = creatNewFile("src/data.csv");
        writeToFile(file, """
                    id,first_name,last_name,email,gender
                    1,Fanchette,Williamson,fwilliamson0@github.com,F
                    2,Aleksandr,Matts,amatts1@webs.com,M
                    3,Maurie,Cordero,mcordero2@google.co.jp,M
                    4,Donnajean,Crowson,dcrowson3@google.com.hk,F
                    5,Ricardo,Gofton,rgofton4@nytimes.com,M
                    6,Gabie,Tregenna,gtregenna5@guardian.co.uk,F
                    7,Marjorie,Blumsom,mblumsom6@joomla.org,F
                    8,Lester,Huyghe,lhuyghe7@jugem.jp,M
                    9,Merrily,Stangoe,mstangoe8@tiny.cc,F
                    10,Reider,Karel,rkarel9@github.io,M
                    11,Dory,Jolliff,djolliffa@wufoo.com,F
                    12,Homerus,Averay,haverayb@skyrock.com,M
                    13,Alyda,Muglestone,amuglestonec@is.gd,F
                    14,Pinchas,Louca,ploucad@google.es,M
                    15,Cherin,Eltringham,celtringhame@parallels.com,F
                    16,Mufi,Rothert,mrothertf@dropbox.com,F
                    17,Jordana,Everex,jeverexg@ucla.edu,F
                    18,Belle,Rother,brotherh@auda.org.au,F
                    19,Clevie,Sifflett,csiffletti@furl.net,M
                    20,Gretchen,Abell,gabellj@1688.com,F
                """);

        System.out.println("Done exercise 1" + "\n");
        Person Bao = new Person("Nguyen", "Bao", Gender.MALE, "bao123@gmail.com");
        Person Christyna = new Person("Dang", "Christyna", Gender.FEMALE, "tyna123@gmail.com");

        System.out.println("Exercise 2: ");
        System.out.println(Bao);
        System.out.println(Christyna);
        System.out.println("\n" + "Exercise 1 for the Array");
        for (Person person : persons(file)) {
            System.out.println(person);
        }
    }

    static File creatNewFile(String path) {
        try {
            File file = new File(path);
            if (!file.exists()) {
                file.createNewFile();
            }
            return file;
        } catch (IOException e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    static void writeToFile(File file, String string) {
        try (FileWriter fileWriter = new FileWriter(file);
             PrintWriter writer = new PrintWriter(fileWriter)) {
            writer.println(string);
        } catch (IOException e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    static List<Integer> indexOfComma(String string) {
        List<Integer> result = new ArrayList<>();
        for (int i = 0; i < string.length(); i++) {
            if (string.charAt(i) == ',') {
                result.add(i);
            }
        }
        return result;
    }


    static List<Person> persons(File file) {
        try {
            List<Person> result = new ArrayList<>();
            Scanner scanner = new Scanner(file);
            scanner.nextLine();
            while (scanner.hasNext()) {
                String tempString = scanner.nextLine();
                Person tempPerson = new Person();
                List<Integer> indexOfComma = indexOfComma(tempString);
                tempPerson.setFirstName(tempString.substring(indexOfComma.get(0) + 1, indexOfComma.get(1)));
                tempPerson.setLastName(tempString.substring(indexOfComma.get(1) + 1, indexOfComma.get(2)));
                tempPerson.setEmail(tempString.substring(indexOfComma.get(2) + 1, indexOfComma.get(3)));
                if (tempString.substring(indexOfComma.get(3) + 1).equalsIgnoreCase("m")) {
                    tempPerson.setGender(Gender.MALE);
                } else {
                    tempPerson.setGender(Gender.FEMALE);
                }
                result.add(tempPerson);
            }
            return result;
        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

}