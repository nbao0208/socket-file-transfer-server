public class Main {
    public static void main(String[] args) {
        System.out.println(sum(1, 2));
    }

    static int sum(int n1, int n2) {
        return n1 + n2;
    }
}