public class Main {
    public static void main(String[] args) {
        int age = 15;
        // a new way of if/ else if/ else but you just should use it when you need a default value
        String message = age >= 18 ? "I'm an adult" : "I'm not an adult";
        System.out.println(message);

    }
}