import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3);
        List<String> names = Arrays.asList("Norris", "Bob", "Christyna");
        printNumber(numbers);
        System.out.println();
        print(names);
    }


    // the character '?' is the unbounded wildcard --> no limit type--> it can take anything
    static void print(List<?> list) {
        list.forEach(e -> {
            System.out.println(e.getClass().getName());
            System.out.println(e);
        });
    }

    // this is upper bounded wildcard, you can set the condition for the type you add
    // meaning that this method just work with the type <= type's extension
    static void printNumber(List<? extends Number> list) {
        list.forEach(e -> {
            System.out.println(e.getClass().getName());
            System.out.println(e);
        });
    }

    // this is lower bounded wildcard, you can set the condition for the type you add
    // meaning that this method just work with the type >= type's extension
    static void printInteger(List<? super Integer> list) {
        list.forEach(e -> {
            System.out.println(e.getClass().getName());
            System.out.println(e);
        });
    }


    // unbounded wildcard meaning all type can access
    // upper bounded wildcard: the type <= type's extension
    // lower bounded wildcard: the type >= type's extension

}