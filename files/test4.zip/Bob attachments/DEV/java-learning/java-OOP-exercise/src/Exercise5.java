import Object.*;

public class Exercise5 {
    public static void main(String[] args) {
        CarDealership vinShowRoom = new CarDealership();
        vinShowRoom.setName("VinFast");
        vinShowRoom.setcarMaxNums(5);
        Car[] cars = {new Car("Mec", 29999.99, Type.PETROL), new Car("Tesla", 79000.99, Type.ELECTRIC)};
        vinShowRoom.setCars(cars);
        System.out.println(vinShowRoom);
        System.out.println("Car has: " + vinShowRoom.numberOfCars());
    }

}
