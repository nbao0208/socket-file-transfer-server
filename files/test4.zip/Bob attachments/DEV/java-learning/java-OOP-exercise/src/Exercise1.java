import Object.Car;
import Object.Type;

public class Exercise1 {
    public static void main(String[] args) {
        Car mercedes = new Car("Mercedes Benz", 2.9, Type.PETROL);
        System.out.println(mercedes);
    }
}
