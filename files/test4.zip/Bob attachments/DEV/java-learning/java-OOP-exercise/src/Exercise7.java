import Object.*;

public class Exercise7 {
    public static void main(String[] args) {
        CarDealership mecShowRoom = new CarDealership();
        mecShowRoom.setName("VinFast");
        mecShowRoom.setcarMaxNums(5);
        Car[] cars = {new Car("Mec", 29999.99, Type.PETROL), new Car("Tesla", 79000.99, Type.ELECTRIC)};
        mecShowRoom.setCars(cars);
        System.out.println(mecShowRoom);
        System.out.println("Car has: " + mecShowRoom.numberOfCars());

        if (mecShowRoom.findCarByManufacturer("Mec") == null) {
            System.out.println("Don't exist in the stock");
        } else {
            System.out.println(mecShowRoom.findCarByManufacturer("Mec"));
        }
    }

}
