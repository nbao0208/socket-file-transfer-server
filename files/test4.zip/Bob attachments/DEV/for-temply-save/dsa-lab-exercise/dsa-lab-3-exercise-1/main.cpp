#include "sort.h"
#include <iostream>
#include <ctime>

using namespace std;


void copyArray(int a[], int b[], int size) {
  for (int i = 0; i < size; i++) {
    b[i] = a[i];
  }
}

double maxIn(double a, double b, double c) {
  if (a > b) {
    if (c > b) {
      return max(a, c);
    } else {
      return a;
    }
  }
  if (c < b) {
    return b;
  }
  return c;
}

double minIn(double a, double b, double c) {
  if (a < b) {
    if (c < b) {
      return min(a, c);
    } else {
      return a;
    }
  }
  if (c > b) {
    return b;
  }
  return c;
}

int main() {
  const int n = 10000;
  int arr[n];
  int arr1[n];
  int arr2[n];
  srand(time(NULL));
  for (int i = 0; i < n; i++) {
    arr[i] = rand();
  }
  copyArray(arr, arr1, n);
  copyArray(arr, arr2, n);

  double insertionSortTime = 0;
  double selectionSortTime = 0;
  double interchangeSortTime = 0;

  clock_t start, end;
  start = clock();
  cout << "insertion sort: " << endl;
  insertionSort(arr, n);
  end = clock();
  insertionSortTime = double(end - start) / CLOCKS_PER_SEC;
  cout << insertionSortTime << endl;

  cout << "selection sort: " << endl;
  start = clock();
  selectionSort(arr1, n);
  end = clock();
  selectionSortTime = double(end - start) / CLOCKS_PER_SEC;
  cout << selectionSortTime << endl;

  cout << "Interchange sort: " << endl;
  start = clock();
  interchangeSort(arr2, n);
  end = clock();
  interchangeSortTime = double(end - start) / CLOCKS_PER_SEC;
  cout << double(end - start) / CLOCKS_PER_SEC << endl;
  double max = maxIn(insertionSortTime, selectionSortTime, insertionSortTime);
  double min = minIn(insertionSortTime, selectionSortTime, insertionSortTime);

  if (insertionSortTime == max) {
    cout << endl << "Slowest is insertion sort" << endl;
  }
  if (selectionSortTime == max) {
    cout << endl << "Slowest is selection sort" << endl;
  }
  if (interchangeSortTime == max) {
    cout << endl << "Slowest is interchange sort" << endl;
  }

  if (insertionSortTime == min) {
    cout << endl << "Fastest is insertion sort" << endl;
  }
  if (selectionSortTime == min) {
    cout << endl << "Fastest is selection sort" << endl;
  }
  if (interchangeSortTime == min) {
    cout << endl << "Fastest is interchange sort" << endl;
  }
  return 0;
}
