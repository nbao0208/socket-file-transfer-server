

#ifndef DSA_LAB_3_EXERCISE_1_SORT_H
#define DSA_LAB_3_EXERCISE_1_SORT_H

void insertionSort(int arr[], int size);

void selectionSort(int arr[], int size);

void interchangeSort(int arr[], int size);

#endif
