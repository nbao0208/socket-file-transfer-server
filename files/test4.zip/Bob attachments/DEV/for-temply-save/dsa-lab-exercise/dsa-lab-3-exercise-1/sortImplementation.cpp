#include "sort.h"

void reSeparateArray(int arr[], int last, int index, int value) {
  for (int i = last; i >= index + 1; i--) {
    arr[i] = arr[i - 1];
  }
  arr[index] = value;
}

void swap(int &a, int &b) {
  a = a + b;
  b = a - b;
  a = a - b;
}

void insertionSort(int arr[], int size) {
  for (int i = 1; i < size; i++) {
    int value = arr[i];
    for (int j = i - 1; j >= 0; j--) {
      if (value > arr[j]) {
        reSeparateArray(arr, i - 1, j + 1, value);
        break;
      } else {
        reSeparateArray(arr, i - 1, 0, value);
      }
    }
  }
}

void selectionSort(int arr[], int size) {
  for (int i = 0; i < size - 1; i++) {
    int minIndex = i;
    for (int j = i + 1; j < size; j++) {
      if (arr[minIndex] < arr[j]) {
        minIndex = j;
      }
    }
    if (i != minIndex) {
      swap(arr[i], arr[minIndex]);
    }
  }
}

void interchangeSort(int arr[], int size) {
  for (int i = 0; i < size - 1; i++) {
    for (int j = i + 1; j < size; ++j) {
      if (arr[j] < arr[i]) {
        swap(arr[j], arr[i]);
      }
    }
  }
}