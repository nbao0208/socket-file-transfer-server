#include "queue.h"

int main() {
  char accept = 'y';
  Queue<int> myQueue;
  //choose size 0 for the begining so that we don't need to enqueue for some first elements, it will be done in the next action
  myQueue.init(0);
  while (accept == 'y') {
    int choice = 0;
    cout << "Choose your choice: " << endl;
    cout << "1. Enqueue value" << endl;
    cout << "2. Dequeue value" << endl;
    cin >> choice;
    switch (choice) {
      case 1: {
        int value = 0;
        cout << "Value to enqueue: ";
        cin >> value;
        myQueue.enqueue(value);
        cout << "Queue after enqueued: " << endl;
        myQueue.print();
        break;
      }
      case 2: {
        cout << "Dequeued value: " << myQueue.dequeue() << endl;
        cout << "Queue after dequeued: " << endl;
        myQueue.print();
        break;
      }
      default: {
        cerr << "Don't have this choice!!" << endl;
        break;
      }
    }
    cout << endl << "Press y to continue, otherwise press any key: ";
    cin >> accept;
  }
  myQueue.release();
  return 0;
}
