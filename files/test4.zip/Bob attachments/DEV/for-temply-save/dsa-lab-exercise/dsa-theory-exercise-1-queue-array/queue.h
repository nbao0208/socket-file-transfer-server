

#ifndef DSA_THEORY_EXERCISE_1_QUEUE_ARRAY_QUEUE_H
#define DSA_THEORY_EXERCISE_1_QUEUE_ARRAY_QUEUE_H

#include <iostream>

using namespace std;

#define MAX_SIZE (unsigned int) 10
#define BEGIN_SIZE (unsigned int) 0

template<typename T>
struct Queue {
  T *data;
  int front;
  int rear;
  unsigned int count = BEGIN_SIZE;
  unsigned int maxSize = MAX_SIZE;

  void init(const unsigned int &queueSize);

  void copyQueue(const Queue<T> &anotherQueue);

  void release();

  bool isEmpty();

  void enqueue(const T &newItem);

  T dequeue();

  T frontValue();

  void print();
};

template<typename T>
void Queue<T>::init(const unsigned int &queueSize) {
  this->data = new T[this->maxSize];
  this->count = queueSize;
}

template<typename T>
void Queue<T>::copyQueue(const Queue<T> &anotherQueue) {
  this->data = anotherQueue.data;
  this->front = anotherQueue.front;
  this->rear = anotherQueue.rear;
  this->count = anotherQueue.count;
}

template<typename T>
void Queue<T>::release() {
  delete[]this->data;
  delete &this->front;
  delete &this->rear;
  this->count = BEGIN_SIZE;
}

template<typename T>
bool Queue<T>::isEmpty() {
  return this->count == BEGIN_SIZE;
}

template<typename T>
void Queue<T>::enqueue(const T &newItem) {
  if (this->isEmpty()) {
    this->front = 0;
    this->rear = 0;
    this->data[this->rear] = newItem;
    this->count++;
    return;
  }
  this->rear++;
  this->data[this->rear] = newItem;
  this->count++;
}

template<typename T>
T Queue<T>::dequeue() {
  if (this->isEmpty()) {
    throw logic_error("Queue is empty!!");
  }

  T frontData = this->data[this->front];
  for (int i = 0; i < this->count - 1; i++) {
    this->data[i] = this->data[i + 1];
  }
  this->rear--;
  this->count--;
  return frontData;
}

template<typename T>
T Queue<T>::frontValue() {
  if (this->isEmpty()) {
    throw logic_error("Queue is empty!!");
  }
  return this->data[this->front];
}

template<typename T>
void Queue<T>::print() {
  if (this->isEmpty()) {
    cout << "Queue is empty!!" << endl;
  }
  for (int i = 0; i < this->count; i++) {
    cout << this->data[i] << " ";
  }
}


#endif
