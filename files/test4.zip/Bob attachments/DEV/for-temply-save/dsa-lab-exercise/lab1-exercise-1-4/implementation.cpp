#include "structure.h"
#include <algorithm>
#include <iostream>

bool isContainIn(const vector<string> &vec, string data) {
    return find(vec.begin(), vec.end(), data) != vec.end();
}

vector<string> getAllLinesInFile(ifstream &input) {
    vector<string> result;
    while (!input.eof()) {
        string temp;
        getline(input, temp);
        result.push_back(temp);
    }
    return result;
}

vector<pair<int, string>> differLineInBothFileFrom(const vector<string> &lines1, const vector<string> &lines2) {
    vector<pair<int, string>> result;
    for (const string &line: lines1) {
        if (!isContainIn(lines2, line)) {
            result.emplace_back(distance(lines1.begin(), find(lines1.begin(), lines1.end(), line)) + 1, line);
        }
    }
    return result;
}

void printInfoIn(const vector<pair<int, string>> &line1, const vector<pair<int, string>> &line2) {
    cout << "first file:" << endl;
    for (const auto &item: line1) {
        cout << item.first << "//" << item.second << endl;
    }
    cout << endl;
    cout << "second file:" << endl;
    for (const auto &item: line2) {
        cout << item.first << "\\" << item.second << endl;
    }
}



