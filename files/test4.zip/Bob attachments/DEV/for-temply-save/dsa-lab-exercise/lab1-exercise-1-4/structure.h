

#ifndef LAB1_EXERCISE_1_4_STRUCTURE_H
#define LAB1_EXERCISE_1_4_STRUCTURE_H

#include <vector>
#include <fstream>

using namespace std;

vector<string> getAllLinesInFile(ifstream &input);

vector<pair<int, string>> differLineInBothFileFrom(const vector<string> &lines1, const vector<string> &lines2);

void printInfoIn(const vector<pair<int, string>> &line1, const vector<pair<int, string>> &line2);


#endif
