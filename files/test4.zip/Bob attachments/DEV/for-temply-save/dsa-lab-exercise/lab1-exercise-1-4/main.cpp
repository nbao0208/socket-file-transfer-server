#include "structure.h"
#include <iostream>

int main() {
    ifstream input1;
    ifstream input2;
    input1.open("../input1.4.1.txt", ios_base::in);
    input2.open("../input1.4.2.txt", ios_base::in);
    if (!input1.is_open() || !input2.is_open()) {
        cerr << "cannot open some input files" << endl;
        return 0;
    }
    vector<string> line1 = getAllLinesInFile(input1);
    vector<string> line2 = getAllLinesInFile(input2);
    vector<pair<int, string>> differLineFromFileOne = differLineInBothFileFrom(line1, line2);
    vector<pair<int, string>> differLineFromFileTwo = differLineInBothFileFrom(line2, line1);
    printInfoIn(differLineFromFileOne, differLineFromFileTwo);
    return 0;
}
