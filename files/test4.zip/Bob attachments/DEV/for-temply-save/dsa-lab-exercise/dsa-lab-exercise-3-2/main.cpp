#include <iostream>
#include "structure.h"

void printArray(int arr[], int size) {
  for (int i = 0; i < size; i++) {
    cout << arr[i] << " ";
  }
}

int main() {
  int size = 0;
  cout << "Size: ";
  cin >> size;
  int arr[size];
  for (int i = 0; i < size; i++) {
    cout << "Index 1: ";
    cin >> arr[i];
  }
  cout << "Before sort: " << endl;
  printArray(arr, size);
  suggestSort(arr, size);
  cout << "After sort: " << endl;
  printArray(arr, size);
  return 0;
}
