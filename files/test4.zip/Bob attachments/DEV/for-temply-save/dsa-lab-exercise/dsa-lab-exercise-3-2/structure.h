

#ifndef DSA_LAB_EXERCISE_3_2_STRUCTURE_H
#define DSA_LAB_EXERCISE_3_2_STRUCTURE_H

#include <vector>
#include <algorithm>

using namespace std;

void suggestSort(int arr[], int size) {
  vector<int> even;
  vector<int> odd;

  for (int i = 0; i < size; i++) {
    if (arr[i] % 2 == 0) {
      even.push_back(arr[i]);
    } else {
      odd.push_back(arr[i]);
    }
  }

  std::sort(even.begin(), even.end());
  std::sort(odd.begin(), odd.end());
  std::reverse(odd.begin(), odd.end());
  int evenIndex = 0;
  int oddIndex = 0;
  for (int i = 0; i < size; i++) {
    if (arr[i] % 2 == 0) {
      arr[i] = even[evenIndex];
      evenIndex++;
    } else {
      arr[i] = odd[oddIndex];
      oddIndex++;
    }
  }
}


#endif
