#include <iostream>
#include "myQueue.h"

int main() {
  myQueue<int> myQueue;
  //enqueue method
  myQueue.enqueue(1);
  myQueue.enqueue(2);
  myQueue.enqueue(3);

  //show queue after push
  cout << "After push: " << endl;
  myQueue.showQueue();

  //dequeue method-->this will be pop the first in element which is one, it will show 2 3
  myQueue.dequeue();
  //show queue after pop
  cout << endl << "Queue after pop: " << endl;
  myQueue.showQueue();

  //when queue is empty but keep deque value
  myQueue.dequeue();
  myQueue.dequeue();
  //--> queue is empty now so it will happen if
  cout << endl;
  myQueue.dequeue();
  return 0;
}
