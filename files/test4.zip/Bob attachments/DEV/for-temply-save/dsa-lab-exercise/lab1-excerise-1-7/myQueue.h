

#ifndef LAB1_EXCERISE_1_7_MYQUEUE_H
#define LAB1_EXCERISE_1_7_MYQUEUE_H

#include <vector>
#include <iostream>

using namespace std;

template<typename T>
class myQueue {
private:
  vector<T> data;
public:
  explicit myQueue(const vector<T> &data) : data(data) {}

  explicit myQueue() {
    vector<T> temp;
    this->data = temp;
  }

  void showQueue() {
    for (const auto &item: this->data) {
      cout << item << " ";
    }
  }

  void enqueue(T value) {
    this->data.push_back(value);
  }

  void dequeue() {
    if (this->data.empty()) {
      throw runtime_error("Queue is empty!!!");
    }
    this->data.erase(this->data.begin());
  }
};


#endif
