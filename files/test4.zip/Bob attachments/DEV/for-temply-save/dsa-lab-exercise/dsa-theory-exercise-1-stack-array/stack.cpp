#include <iostream>
#include "stack.h"

//using namespace std;
//
//template<typename T>
//void Stack<T>::init(const unsigned int &size) {
//  this->realSize = size;
//  this->item = new T[this->maxSize];
//}
//
//template<typename T>
//void Stack<T>::copyStack(const Stack<T> &anotherStack) {
//  this->item = anotherStack.item;
//  this->top = anotherStack.top;
//  this->realSize = anotherStack.realSize;
//}
//
//template<typename T>
//void Stack<T>::release() {
//  delete this->item;
//  this->top = -1;
//  this->realSize = EMPTY_SIZE;
//}
//
//template<typename T>
//bool Stack<T>::isEmpty() {
//  return this->top == EMPTY_TOP_INDEX;
//}
//
//template<typename T>
//void Stack<T>::push(const T &data) {
//  if (this->realSize == this->maxSize) {
//    cerr << "Stack storage is already full!!" << endl;
//    return;
//  }
//  this->item[realSize] = data;
//  this->top = realSize;
//  this->realSize++;
//}
//
//template<typename T>
//void Stack<T>::pop() {
//  if (this->isEmpty()) {
//    cerr << "Stack is empty so cannot pop value!!" << endl;
//    return;
//  }
//  delete &this->item[realSize - 1];
//  this->realSize--;
//  this->top = realSize - 1;
//}
//
//template<typename T>
//T Stack<T>::topValue() {
//  return this->item[this->top];
//}
//
//template<typename T>
//void Stack<T>::print() {
//  for (int i = this->realSize - 1; i >= 0; i--) {
//    cout << this->item[i] << " ";
//  }
//}





