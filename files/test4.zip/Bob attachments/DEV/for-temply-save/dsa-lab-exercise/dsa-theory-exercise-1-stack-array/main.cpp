#include "stack.h"


int main() {
  Stack<int> myStack;
  myStack.init(0);
  char accept = 'y';
  while (accept == 'y') {
    int choice = 0;
    cout << "Choose your choice: " << endl;
    cout << "1. Push method" << endl;
    cout << "2. Pop method" << endl;
    cin >> choice;
    switch (choice) {
      case 1: {
        int value;
        cout << "Value to push: ";
        cin >> value;
        myStack.push(value);
        cout << "Stack after pushing value: " << endl;
        myStack.print();
        break;
      }
      case 2: {
        myStack.pop();
        cout << "Stack after pop value: " << endl;
        myStack.print();
        break;
      }

      default: {
        cerr << "Don't have this choice" << endl;
        break;
      }
    }
    cout << endl << "Press y to continue, otherwise press any key to stop: ";
    cin >> accept;
  }
  myStack.release();
  return 0;
}
