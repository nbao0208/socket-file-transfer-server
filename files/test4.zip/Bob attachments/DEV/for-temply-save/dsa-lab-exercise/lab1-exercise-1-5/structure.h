

#ifndef LAB1_EXERCISE_1_5_STRUCTURE_H
#define LAB1_EXERCISE_1_5_STRUCTURE_H

#include <fstream>

using namespace std;

void printFirstNLines(char* path, const int &n);

void printLastNLines(char* path, const int &n);

#endif
