#include <iostream>
#include "structure.h"

int main(int argc, char *argv[]) {
  if (stoi(argv[1]) == 0) {
    printFirstNLines(argv[3], stoi(argv[2]));
    return 0;
  }
  printLastNLines(argv[3], stoi(argv[2]));
  return 0;
}
