#include "structure.h"
#include <iostream>
#include <vector>

void printFirstNLines(char *path, const int &n) {
  ifstream input(path, ios_base::in);
  if (!input.is_open()) {
    throw runtime_error("cannot open file!!");
  }
  for (int i = 0; i < n; i++) {
    string temp;
    getline(input, temp);
    cout << temp << endl;
  }
}

void printLastNLines(char *path, const int &n) {
  ifstream input(path, ios::ate | ios::binary);
  if (!input.is_open()) {
    throw runtime_error("cannot open file!!");
  }
  streampos position = input.tellg();
  vector<string> lines;
  int count = 0;
  position -= 1;
  input.seekg(position);
  while (count < n) {
    if (position <= 0) {
      break;
    }
    char ch;
    input.get(ch);
    if (ch == '\n') {
      string temp;
      getline(input, temp);
      lines.push_back(temp);
      position -= temp.size();
      input.seekg(position);
      count++;
    } else {
      position -= 1;
      input.seekg(position);
    }
  }
  for (int i = lines.size() - 1; i >= 0; i--) {
    cout << lines[i] << endl;
  }
}