#include "queue.h"
#include <iostream>



template<typename T>
void doing() {
  char accept = 'y';
  Queue<T> myQueue;
  myQueue.init();
  while (accept == 'y') {
    int choice = 0;
    cout << "Choose your choice: " << endl;
    cout << "1. Enqueue data" << endl;
    cout << "2. Dequeue data" << endl;
    cin >> choice;
    switch (choice) {
      case 1: {
        int value = 0;
        cout << "Value to enqueue: " << endl;
        cin >> value;
        myQueue.enqueue(value);
        cout << "Queue after enqueued: " << endl;
        myQueue.print();
        break;
      }
      case 2: {
        cout << "Dequeued value: " << myQueue.dequeue() << endl;
        cout << "Queue after dequeued:" << endl;
        myQueue.print();
        break;
      }
      default: {
        cerr << "Don't have this choice!!" << endl;
        break;
      }
    }
    cout << endl << "Press y to continue, otherwise press any key: ";
    cin >> accept;
  }
  myQueue.release();
}