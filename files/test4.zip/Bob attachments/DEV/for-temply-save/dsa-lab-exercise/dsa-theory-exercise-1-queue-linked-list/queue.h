

#ifndef DSA_THEORY_EXERCISE_1_QUEUE_LINKED_LIST_QUEUE_H
#define DSA_THEORY_EXERCISE_1_QUEUE_LINKED_LIST_QUEUE_H

#include <iostream>

using namespace std;
#define BEGIN_SIZE (unsigned int) 0
#define MAX_SIZE (unsigned int) 10

template<typename T>
struct Node {
  T data;
  Node *next;

  Node(T data) {
    this->data = data;
    this->next = nullptr;
  }
};

template<typename T>
struct Queue {
  Node<T> *front;
  Node<T> *rear;
  int size = BEGIN_SIZE;
  int maxSize = MAX_SIZE;

  void init();

  void release();

  bool isEmpty();

  void enqueue(const T &newData);

  T dequeue();

  T frontValue();

  void print();
};

template<typename T>
void Queue<T>::init() {
  this->front = nullptr;
  this->rear = nullptr;
}

template<typename T>
void Queue<T>::release() {
  Node<T> *current = this->front;
  Node<T> *after = this->front;
  while (current != nullptr) {
    current = current->next;
    delete &after;
    after = current;
  }
  this->size = BEGIN_SIZE;
}

template<typename T>
bool Queue<T>::isEmpty() {
  return this->size == 0;
}

template<typename T>
void Queue<T>::enqueue(const T &newData) {
  if (this->size == this->maxSize) {
    throw runtime_error("Queue is almost full!!");
  }
  if (this->isEmpty()) {
    this->front = new Node(newData);
  } else {
    if (this->rear == nullptr) {
      this->rear = new Node(newData);
      this->front->next = this->rear;
    } else {
      this->rear->next = new Node(newData);
      this->rear = this->rear->next;
    }
  }
  this->size++;
}

template<typename T>
T Queue<T>::dequeue() {
  if (this->isEmpty()) {
    throw runtime_error("Queue is empty!!");
  }

  T frontData = this->front->data;
  Node<T> *temp = this->front->next;
  delete this->front;
  this->front = temp;
  this->size--;
  return frontData;
}

template<typename T>
T Queue<T>::frontValue() {
  if (this->isEmpty()) {
    throw runtime_error("Queue is empty!!");
  }
  return this->front->data;
}

template<typename T>
void Queue<T>::print() {
  if (this->isEmpty()) {
    cout << "Queue is empty!!" << endl;
    return;
  }

  Node<T> *temp = this->front;
  while (temp != nullptr) {
    cout << temp->data << " ";
    temp = temp->next;
  }
}

template<typename T>
void doing();


#endif
