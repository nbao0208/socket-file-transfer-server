

#ifndef LAB1_EXERCISE_1_8_STRUTURE_H
#define LAB1_EXERCISE_1_8_STRUTURE_H

#include <string>

using namespace std;

bool isPalindrome(const string &str);

void printResultOfCheckingInputInFile(const string &path);

#endif
