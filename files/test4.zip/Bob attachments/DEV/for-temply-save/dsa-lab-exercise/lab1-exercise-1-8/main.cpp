#include "struture.h"

int main() {
  printResultOfCheckingInputInFile("../input1.8.1.txt");
  return 0;
}
