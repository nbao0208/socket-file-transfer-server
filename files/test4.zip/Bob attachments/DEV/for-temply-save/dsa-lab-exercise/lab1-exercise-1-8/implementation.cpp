#include "struture.h"
#include <algorithm>
#include <fstream>
#include <iostream>

bool isPalindrome(const string &str) {
  string temp = str;
  std::reverse(temp.begin(), temp.end());
  return temp == str;
}

void printResultOfCheckingInputInFile(const string &path) {
  ifstream input;
  input.open(path, ios_base::in);
  if (!input.is_open()) {
    throw runtime_error("cannot open input file");
  }
  while (!input.eof()) {
    string temp;
    getline(input, temp);
    cout << temp << " is ";
    if (isPalindrome(temp)) {
      cout << "palindrome" << endl;
    } else {
      cout << "not palindrome" << endl;
    }
  }
}