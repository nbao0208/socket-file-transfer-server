#include "structure.h"
#include <fstream>
#include <iostream>

#define ERROR_INDEX (-1)

int singleLinearSearch(vector<int> arr, const int &value) {
  for (int i = 0; i < arr.size(); i++) {
    if (arr[i] == value) {
      return i;
    }
  }
  return ERROR_INDEX;
}

vector<int> linearSearch(vector<int> arr, int value) {
  vector<int> result;
  for (int i = 0; i < arr.size(); i++) {
    if (arr[i] == value) {
      result.push_back(i);
    }
  }
  return result;
}

vector<int> linearSentinelSearch(vector<int> arr, int value) {
  vector<int> result;
  int index = 0;
  int lastValue = arr[arr.size() - 1];
  arr[arr.size() - 1] == value;
  while (index < arr.size() - 1) {
    if (arr[index] == value) {
      result.push_back(index);
    }
    index++;
  }

  arr[arr.size() - 1] = lastValue;
  if (lastValue == value) {
    result.push_back(arr.size() - 1);
  }
  return result;
}

void helpBinarySearch(vector<int> &index, vector<int> arr, int left, int right, int value) {
  if (right - left > 1) {
    int middle = (right + left) / 2;
    if (arr[middle] == value) {
      if (index.empty() || singleLinearSearch(index, middle) == ERROR_INDEX) {
        index.push_back(middle);
      }
    }
    helpBinarySearch(index, arr, left, middle, value);
    helpBinarySearch(index, arr, middle, right, value);
  }
  if (right == left) {
    if (arr[right] == value) {
      if (index.empty() || singleLinearSearch(index, right) == ERROR_INDEX) {
        index.push_back(right);
      }
    }
  } else {
    if (arr[right] == value) {
      if (index.empty() || singleLinearSearch(index, right) == ERROR_INDEX) {
        index.push_back(right);
      }
    }
    if (arr[left] == value) {
      if (index.empty() || singleLinearSearch(index, left) == ERROR_INDEX) {
        index.push_back(left);
      }

    }
  }
}

vector<int> binarySearch(vector<int> arr, int value) {

  vector<int> result;
  helpBinarySearch(result, arr, 0, arr.size() - 1, value);
  return result;
}

vector<int> numberFrom(char *path) {
  ifstream input;
  input.open(path, ios_base::in);
  if (!input.is_open()) {
    throw runtime_error("Cannot open input file!!");
  }
  vector<int> result;
  int temp = 0;
  input >> temp;
  while (!input.eof()) {
    input >> temp;
    result.push_back(temp);
  }
  return result;
}

void printPositionTo(char *path, const int &option, vector<int> arr, int value) {
  ofstream output;
  output.open(path, ios_base::out);
  if (!output.is_open()) {
    throw runtime_error("Cannot open output file!!");
  }
  vector<int> index;
  switch (option) {
    case 1: {
      index = linearSearch(arr, value);
      break;
    }
    case 2: {
      index = linearSentinelSearch(arr, value);
      break;
    }
    case 3: {
      index = binarySearch(arr, value);
      break;
    }
    default: {
      cerr << "Don't have this option";
      break;
    }
  }
  for (int i = 0; i < index.size(); i++) {
    if (i != index.size() - 1) {
      output << index[i] << " ";
    } else {
      output << index[i];
    }
  }
}



