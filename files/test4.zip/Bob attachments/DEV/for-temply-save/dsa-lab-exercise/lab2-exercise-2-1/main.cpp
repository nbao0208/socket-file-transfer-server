#include "structure.h"
#include <iostream>
#include <string>

int main(int argv, char *argc[]) {
  if (argv < 6) {
    cerr << "Syntax error!!";
    return 0;
  }
  vector<int> arr = numberFrom(argc[4]);
  printPositionTo(argc[5], stoi(string(argc[2])), arr, stoi(string(argc[3])));
  cout << "Check output file!!!" << endl;
  return 0;
}
