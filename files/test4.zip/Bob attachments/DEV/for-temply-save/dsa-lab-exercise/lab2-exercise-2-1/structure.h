

#ifndef LAB2_EXERCISE_2_1_STRUCTURE_H
#define LAB2_EXERCISE_2_1_STRUCTURE_H

#include <vector>

using namespace std;

vector<int> linearSearch(vector<int> arr, int value);

vector<int> linearSentinelSearch(vector<int> arr, int value);

vector<int> binarySearch(vector<int> arr, int value);

vector<int> numberFrom(char *path);

void printPositionTo(char *path, const int &option, vector<int> arr, int value);

#endif
