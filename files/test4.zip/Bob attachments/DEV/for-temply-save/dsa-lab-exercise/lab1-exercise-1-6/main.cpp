#include <iostream>
#include "myStack.h"

int main() {
  myStack<char> myStack;

  //push method
  myStack.push('a');
  myStack.push('b');
  myStack.push('c');
  //print stack
  cout << "After push value: ";
  myStack.showStack();

  cout << endl;
  //pop method
  myStack.pop();
  //show stack
  cout << "After pop value: ";
  myStack.showStack();

  cout << endl << "when stack is empty but keep pop element" << endl;
  //empty case
  myStack.pop();
  myStack.pop();
  //stack is empty now so when we pop another element it will throw exception
  myStack.pop();
  return 0;
}
