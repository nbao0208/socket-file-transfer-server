

#ifndef LAB1_EXERCISE_1_6_MYSTACK_H
#define LAB1_EXERCISE_1_6_MYSTACK_H

#include <vector>
#include <stdexcept>
#include <iostream>

using namespace std;

template<typename T>
class myStack {
private:
  vector<T> data;
public:
  explicit myStack(const vector<T> &data) : data(data) {}

  explicit myStack() {
    vector<T> temp;
    this->data = temp;
  }

  void showStack();

  void push(T value);

  void pop();

};

template<typename T>
void myStack<T>::showStack() {
  for (int i = this->data.size() - 1; i >= 0; i--) {
    cout << this->data[i]<<" ";
  }
}

template<typename T>
void myStack<T>::push(T value) {
  this->data.push_back(value);
}

template<typename T>
void myStack<T>::pop() {
  if (this->data.empty()) {
    throw runtime_error("stack is empty!!");
  }
  this->data.pop_back();
}

#endif
