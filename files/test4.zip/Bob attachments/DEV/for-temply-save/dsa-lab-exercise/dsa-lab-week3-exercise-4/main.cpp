#include "structure.h"

using namespace std;

int main() {
  int row, col;

  cout << "Row: ";
  cin >> row;
  cout << "Column: ";
  cin >> col;
  if (row * col <= 0) {
    cerr << "Invalid value!!";
    return 0;
  }

  vector<vector<int>> arr = randomArray(col, row);
  cout << "Before: " << endl;
  printArray(arr);
  sortBySpiral(arr);
  cout << "After: " << endl;
  printArray(arr);
  return 0;
}
