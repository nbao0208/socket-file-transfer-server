

#ifndef DSA_LAB_WEEK3_EXERCISE_4_STRUCTURE_H
#define DSA_LAB_WEEK3_EXERCISE_4_STRUCTURE_H

#include <vector>
#include <algorithm>
#include <iostream>
using namespace std;

vector<vector<int>> randomArray(const int &column, const int &row);

void sortBySpiral(vector<vector<int>> &arr);

void printArray(const vector<vector<int>> &arr);

#endif