#include "structure.h"
#include <cstdlib>
#include <ctime>

vector<int> sortTwoDimensionalArrayByStraight(vector<vector<int>> &arr) {
  vector<int> result;
  for (const auto &item: arr) {
    for (const auto &item1: item) {
      result.push_back(item1);
    }
  }
  std::sort(result.begin(), result.end());
  return result;
}

vector<vector<int>> randomArray(const int &column, const int &row) {
  vector<vector<int>> result;
  srand(time(0));
  for (int i = 0; i < row; i++) {
    vector<int> temp;
    for (int j = 0; j < column; j++) {
      temp.push_back(rand() % 100);
    }
    result.push_back(temp);
  }
  return result;
}

void sortBySpiral(vector<vector<int>> &arr) {
  vector<int> sortedStraight = sortTwoDimensionalArrayByStraight(arr);
  int index = 0;
  int row = arr.size();
  int col = arr[0].size();
  int countRow = 0;
  int countCol = 0;
  while (countRow <= (row + 1) / 2 - 1 || countCol <= (col + 1) / 2 - 1) {
    for (int i = countRow; i <= col - countRow - 1; i++) {
      arr[countRow][i] = sortedStraight[index];
      index++;
    }

    for (int i = countCol + 1; i <= row - countCol - 2; i++) {
      arr[i][col - countCol - 1] = sortedStraight[index];
      index++;
    }

    for (int i = col - countRow - 1; i >= countRow; i--) {
      arr[row - countRow - 1][i] = sortedStraight[index];
      index++;
    }

    for (int i = row - countCol - 2; i >= countCol + 1; i--) {
      arr[i][countCol] = sortedStraight[index];
      index++;
    }
    if (countRow <= row / 2) {
      countRow++;
    }
    if (countCol <= col / 2) {
      countCol++;
    }
  }
}

void printArray(const vector<vector<int>> &arr) {
  for (const auto &item: arr) {
    for (const auto &item1: item) {
      cout << item1 << " ";
    }
    cout << endl;
  }
}
