#include "structure.h"
#include <iostream>

int main(int argv, char *argc[]) {
  vector<Word *> dictionary = extractDictionaryFrom("../English-Vietnamese Dictionary.txt");
  vector<string> suggestedWord = extractSuggestedWord(argv, argc);
  printWordSuggestionTo(argc[argv - 1], suggestedWord, dictionary);
  return 0;
}
