

#ifndef LAB2_EXERCISE_2_2_STRUCTURE_H
#define LAB2_EXERCISE_2_2_STRUCTURE_H

#include <vector>
#include <fstream>

using namespace std;

struct Word {
  string word;
  string meaning;

  Word(string word, string meaning) {
    this->word = word;
    this->meaning = meaning;
  }
};

vector<Word *> extractDictionaryFrom(string path);

vector<string> extractSuggestedWord(int argv, char *argc[]);

void printWordSuggestionTo(char *path, const vector<string> &suggestedWord, const vector<Word *> &dictionary);


#endif