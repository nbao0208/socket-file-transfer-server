#include "structure.h"
#include <iostream>

string meaningOf(const string &word, const vector<Word *> &dictionary) {
  for (const auto &item: dictionary) {
    if (word == item->word) {
      return item->meaning;
    }
  }
  return "Don't have meaning of this word in dictionary";
}

vector<string> extractSuggestedWord(int argv, char *argc[]) {
  vector<string> result;
  for (int i = 2; i < argv - 1; i++) {
    result.emplace_back(argc[i]);
  }
  return result;
}

vector<Word *> extractDictionaryFrom(string path) {
  ifstream input;
  input.open(path, ios_base::in);
  if (!input.is_open()) {
    throw runtime_error("Cannot open input file!!");
  }

  vector<Word *> result;

  while (!input.eof()) {
    string temp;
    getline(input, temp);
    int positionOfSpecialChar = temp.find(':');
    result.push_back(new Word(temp.substr(0, positionOfSpecialChar),
                              temp.substr(positionOfSpecialChar + 1, temp.size() - positionOfSpecialChar - 1)));
  }
  return result;
}

void printWordSuggestionTo(char *path, const vector<string> &suggestedWord, const vector<Word *> &dictionary) {
  ofstream output;
  output.open(path, ios_base::out);
  if (!output.is_open()) {
    throw runtime_error("Cannot open output file!!");
  }
  cout << "Translating..." << endl;
  for (const auto &item: suggestedWord) {
    output << item << ": " << meaningOf(item, dictionary) << endl;
  }
  cout << "Check result in output file" << endl;
}

