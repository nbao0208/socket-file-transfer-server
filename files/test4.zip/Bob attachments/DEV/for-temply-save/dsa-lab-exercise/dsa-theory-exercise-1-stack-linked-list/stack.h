

#ifndef DSA_THEORY_EXERCISE_1_STACK_LINKED_LIST_STACK_H
#define DSA_THEORY_EXERCISE_1_STACK_LINKED_LIST_STACK_H

#include <iostream>

using namespace std;

#define MAX_SIZE (unsigned int) 10
#define BEGIN_SIZE (unsigned int) 0

template<typename T>
struct Node {
  T data;
  Node *next;

  Node(T data) {
    this->data = data;
    this->next = nullptr;
  }
};

template<typename T>
struct Stack {
  Node<T> *top;

  unsigned int maxSize = MAX_SIZE;

  unsigned int size;

  void init();

  void copyStack(Stack<T> anotherStack);

  void release();

  bool isEmpty();

  void push(const T &data);

  T pop();

  T topValue();

  void print();
};

template<typename T>
void Stack<T>::init() {
  this->top = nullptr;
  this->size = BEGIN_SIZE;
}

template<typename T>
void Stack<T>::copyStack(Stack<T> anotherStack) {
  if (anotherStack.isEmpty()) {
    throw runtime_error("Stack is empty so cannot copy");
  }
  this->top = new Node(anotherStack.top->data);
  Node<T> *temp1 = this->top;
  Node<T> *temp2 = anotherStack.top->next;
  while (temp2 != nullptr) {
    temp1->next = new Node(temp2->data);
    temp2 = temp2->next;
    temp1 = temp1->next;
  }
  this->size = anotherStack.size;
}

template<typename T>
void Stack<T>::release() {
  if (this->isEmpty()) {
    cout << "Stack is already released" << endl;
  }
  Node<T> *current = this->top;
  Node<T> *before = this->top;
  while (current != nullptr) {
    current = current->next;
    free(before);
    before = current;
  }
}

template<typename T>
bool Stack<T>::isEmpty() {
  return this->top == nullptr;
}

template<typename T>
void Stack<T>::push(const T &data) {
  if (size == maxSize) {
    throw runtime_error("Stack is almost full!!");
  }

  if (this->isEmpty()) {
    this->top = new Node(data);
  } else {
    Node<T> *temp = this->top;
    this->top = new Node(data);
    this->top->next = temp;
  }
  this->size++;
}

template<typename T>
T Stack<T>::pop() {
  if (this->isEmpty()) {
    throw runtime_error("Stack is empty so cannot pop any elements!!");
  }

  T topValue = this->top->data;
  Node<T> *temp = this->top->next;
  delete this->top;
  this->top = temp;
  this->size--;
  return topValue;
}

template<typename T>
T Stack<T>::topValue() {
  if (this->isEmpty()) {
    throw runtime_error("Stack is empty!!");
  }
  return this->top->data;
}

template<typename T>
void Stack<T>::print() {
  if (this->isEmpty()) {
    cout << "Stack is empty!!" << endl;
  }
  Node<T> *temp = this->top;
  while (temp != nullptr) {
    cout << temp->data << " ";
    temp = temp->next;
  }
}

#endif
