

#ifndef DSA_THEORY_EXERCISE_1_STACK_LINKED_LIST_RECURSIVE_STACK_H
#define DSA_THEORY_EXERCISE_1_STACK_LINKED_LIST_RECURSIVE_STACK_H
#define MAX_SIZE (unsigned int) 10
#define BEGIN_SIZE (unsigned int) 0

#include <iostream>

using namespace std;

template<typename T>
struct Node {
  T data;
  Node *next;

  Node(T data) {
    this->data = data;
    this->next = nullptr;
  }
};

template<typename T>
struct Stack {
  Node<T> *top;

  unsigned int maxSize = MAX_SIZE;

  unsigned int size;

  void init();

  void copyStack(Node<T> *node);

  void release(Node<T> *node);

  bool isEmpty();

  void push(const T &data);

  T pop();

  T topValue();

  void print(Node<T> *node);
};

template<typename T>
void Stack<T>::init() {
  this->top = nullptr;
  this->size = BEGIN_SIZE;
}

template<typename T>
void Stack<T>::copyStack(Node<T> *node) {
  if (node == nullptr) {
    return;
  }
  copyStack(node->next);
  this->push(node->data);
  this->size++;
}

template<typename T>
void Stack<T>::release(Node<T> *node) {
  if (node == nullptr) {
    return;
  }
  Node<T> *temp = node->next;
  free(node);
  release(temp);
}

template<typename T>
bool Stack<T>::isEmpty() {
  return this->top == nullptr;
}

template<typename T>
void Stack<T>::push(const T &data) {
  if (size == maxSize) {
    throw runtime_error("Stack is almost full!!");
  }

  if (this->isEmpty()) {
    this->top = new Node(data);
  } else {
    Node<T> *temp = this->top;
    this->top = new Node(data);
    this->top->next = temp;
  }
  this->size++;
}

template<typename T>
T Stack<T>::pop() {
  if (this->isEmpty()) {
    throw runtime_error("Stack is empty so cannot pop any elements!!");
  }

  T topValue = this->top->data;
  Node<T> *temp = this->top->next;
  free(this->top);
  this->top = temp;
  this->size--;
  return topValue;
}

template<typename T>
T Stack<T>::topValue() {
  if (this->isEmpty()) {
    throw runtime_error("Stack is empty!!");
  }
  return this->top->data;
}

template<typename T>
void Stack<T>::print(Node<T> *node) {
  if (this->isEmpty()) {
    cout << "Stack is empty" << endl;
    return;
  }
  if (node == nullptr) {
    return;
  }
  cout << node->data << " ";
  print(node->next);
}


#endif
