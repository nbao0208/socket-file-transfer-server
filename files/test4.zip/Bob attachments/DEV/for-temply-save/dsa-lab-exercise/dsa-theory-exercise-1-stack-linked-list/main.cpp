#include "recursive_stack.h"

int main() {
  char accept = 'y';
  Stack<int> myStack;
  myStack.init();
  Stack<int> myStack2;
  myStack2.init();
  while (accept == 'y') {
    int choice = 0;
    cout << "Choose your choice: " << endl;
    cout << "1. Push data" << endl;
    cout << "2. Pop data" << endl;
    cin >> choice;
    switch (choice) {
      case 1: {
        int data = 0;
        cout << "Your data to push: ";
        cin >> data;
        myStack.push(data);
        cout << "After pushing value: " << endl;
        myStack.print(myStack.top);
        break;
      }
      case 2: {
        int popElement = myStack.pop();
        cout << "Pop element: " << popElement << endl;
        cout << "After pop value: " << endl;
        myStack.print(myStack.top);
        break;
      }
      default: {
        cerr << "Don't have this choice" << endl;
        break;
      }
    }
    cout << endl << "Press y to continue, otherwise press any key: ";
    cin >> accept;
  }
  myStack2.copyStack(myStack.top);
  cout << myStack2.top->data << endl;
  cout << "Stack 2 after copy from stack 1: " << endl;
  myStack2.print(myStack2.top);
  myStack.release(myStack.top);
  myStack2.release(myStack2.top);
  return 0;
}
