#include "sort.h"

void merge(int *&arr, int left, int mid, int right) {
  int n1 = mid - left + 1;
  int n2 = right - mid;

  int* L = new int[n1];
  int* R = new int[n2];

  for (int i = 0; i < n1; i++)
    L[i] = arr[left + i];
  for (int i = 0; i < n2; i++)
    R[i] = arr[mid + 1 + i];

  int i = 0, j = 0, k = left;
  while (i < n1 && j < n2) {
    if (L[i] <= R[j]) {
      arr[k] = L[i];
      i++;
    } else {
      arr[k] = R[j];
      j++;
    }
    k++;
  }

  while (i < n1) {
    arr[k] = L[i];
    i++;
    k++;
  }

  while (j < n2) {
    arr[k] = R[j];
    j++;
    k++;
  }

  delete[] L;
  delete[] R;
}

void mergeSort(int *&arr, int left, int right) {
  if (left >= right)
    return;
  int mid = left + (right - left) / 2;
  mergeSort(arr, left, mid);
  mergeSort(arr, mid + 1, right);
  merge(arr, left, mid, right);
}

int getMax(int *arr, int n) {
  int max = arr[0];
  for (int i = 1; i < n; i++)
    if (arr[i] > max)
      max = arr[i];
  return max;
}

void countSort(int *&arr, int n, int exp) {
  int* output = new int[n];
  int count[10] = {0};

  for (int i = 0; i < n; i++)
    count[(arr[i] / exp) % 10]++;

  for (int i = 1; i < 10; i++)
    count[i] += count[i - 1];

  for (int i = n - 1; i >= 0; i--) {
    output[count[(arr[i] / exp) % 10] - 1] = arr[i];
    count[(arr[i] / exp) % 10]--;
  }

  for (int i = 0; i < n; i++)
    arr[i] = output[i];

  delete[] output;
}

void radixSort(int *&arr, int n) {
  int m = getMax(arr, n);

  for (int exp = 1; m / exp > 0; exp *= 10)
    countSort(arr, n, exp);
}

void countingSort(int *arr, int n) {
  int max = *max_element(arr, arr + n);
  int min = *min_element(arr, arr + n);
  int range = max - min + 1;

  int* count = new int[range] {0};
  int* output = new int[n];

  for (int i = 0; i < n; i++)
    count[arr[i] - min]++;

  for (int i = 1; i < range; i++)
    count[i] += count[i - 1];

  for (int i = n - 1; i >= 0; i--) {
    output[count[arr[i] - min] - 1] = arr[i];
    count[arr[i] - min]--;
  }

  for (int i = 0; i < n; i++)
    arr[i] = output[i];

  delete[] count;
  delete[] output;
}


void printArray(int *arr, int size){
  for (int i = 0; i < size; i++) {
    cout<<arr[i]<<" ";
  }
}