#include "sort.h"

int main() {
  int n;
  cout << "Enter number of elements: ";
  cin >> n;

  int* arr = new int[n];
  int* arr2 = new int[n];
  int* arr3 = new int[n];
  srand(time(0));

  for (int i = 0; i < n; i++) {
    arr[i] = rand() % 1000;
    arr2[i] = arr[i];
    arr3[i] = arr[i];
  }
  cout<<"Before sort: "<<endl;
  printArray(arr,n);
  cout<<endl;

  clock_t start = clock();
  mergeSort(arr, 0, n - 1);
  clock_t end = clock();

  double time_taken_MergeSort = double(end - start) / double(CLOCKS_PER_SEC);

  cout<<"After merge sort: "<<endl;
  printArray(arr,n);
  cout<<endl;

  cout << "MergeSort Time taken: " << time_taken_MergeSort << " sec" << endl;

  start = clock();
  radixSort(arr2, n);
  end = clock();

  double time_taken_RadixSort = double(end - start) / double(CLOCKS_PER_SEC);

  cout<<"After radix sort: "<<endl;
  printArray(arr2,n);
  cout<<endl;

  cout << "RadixSort Time taken: " << time_taken_RadixSort << " sec" << endl;

  start = clock();
  countingSort(arr3, n);
  end = clock();

  double time_taken_CountingSort = double(end - start) / double(CLOCKS_PER_SEC);

  cout<<"After counting sort: "<<endl;
  printArray(arr3,n);
  cout<<endl;

  cout << "CountingSort Time taken: " << time_taken_CountingSort << " sec" << endl;


  free(arr);
  free(arr2);
  free(arr3);
  return 0;
}
