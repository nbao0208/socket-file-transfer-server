

#ifndef DSA_LAB_WEEK4_EXERCISE_2_SORT_H
#define DSA_LAB_WEEK4_EXERCISE_2_SORT_H
#include <ctime>
#include <cstdlib>
#include <iostream>
using namespace std;
void mergeSort(int *&arr, int left, int right);

void radixSort(int *&arr, int n);

void countingSort(int *arr, int n);

void printArray(int *arr, int size);
#endif
