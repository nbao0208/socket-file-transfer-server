

#ifndef DSA_LAB_MIDTERM_EXERCISE3_STRUCTURE_H
#define DSA_LAB_MIDTERM_EXERCISE3_STRUCTURE_H
#include <fstream>
#include <vector>
#include <string>
using namespace std;
struct song{
  string track;
  string artist;
  string streams;
  int explicitTrack;

  song(string track, string artist, string streams; int explicitTrack){
    this->track = track;
    this->artist = artist;
    this->streams = streams;
    this->explicitTrack = explicitTrack;
  }
};

vector<song*> songFrom(const string &path);

void printTo(const string &path, const vector<song*> &songs);
#endif
