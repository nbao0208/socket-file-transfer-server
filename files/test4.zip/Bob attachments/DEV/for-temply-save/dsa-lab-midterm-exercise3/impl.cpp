#include "structure.h"
vector<string> splitString(const string &str, char c) {
  vector<string> result;
  int index = 0;
  for (int i = 0; i < str.size(); i++) {
    if(str[i] == c){
      result.push_back(str.substr(index,i-index));
      index = i+1;
    }
  }
  result.push_back(str.substr(index, str.size()-index));
  return result;
}
vector<song*> songFrom(const string &path){
  vector<song*> result;
  ifstream input;
  input.open(path, ios_base::in);
  string temp;
  getline(input, temp);
  while(!input.eof()){
    getline(input, temp);
    vector<string> data = splitString(temp);
    result.push_back(new song(data[0], data[1], data[2], stoi(data[3])));
  }
  return result;
}

void printTo(const string &path, const vector<song*> &songs){
  ofstream output;
  output.open(path, ios_base::out);
  for (const auto &item: songs){
    if(item->explicitTrack == 1){
      output<<item->track<<", "<<item->artist<<", "<<item->streams;
    }
    output<<endl;
  }
}