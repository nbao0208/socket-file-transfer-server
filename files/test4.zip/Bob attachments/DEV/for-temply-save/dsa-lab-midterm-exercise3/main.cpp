#include "structure.h"

int main() {
  vector<song*> songs = songFrom("../input_3.txt");
  printTo("../output_3.txt",songs);
  return 0;
}
