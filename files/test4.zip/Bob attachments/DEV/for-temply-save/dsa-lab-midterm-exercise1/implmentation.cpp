#include "structure.h"
#include <algorithm>

void dataFromFile(const string &path, vector<int>&number, int &target){
  ifstream input;
  input.open(path,ios_base::in);

  int temp;
  cin>>temp;
  cin>>temp;
  target = temp;
  while(!input.eof()){
    cin>>temp;
    number.push_back(temp);
  }
}

pair<int, int> satisfyPair(const vector<int> &number, const int &target){
  vector<pair<int,int>>pairs;
  for(int i = 0; i<number.size()-1;i++){
    for(int j = i+1; j<number.size();j++){
      if(number[i] + number[j] == target){
        pairs.push_back(pair<int,int>(number[i],number[j]));
      }
    }
  }
  if(pairs.empty()){
    return pair<int,int>(-1,-1);
  }
  std::sort(pairs.begin(), pairs.end());
  return pairs[pairs.size()-1];
}

void printResultTo(const string &path, const pair<int,int> &result){
  ofstream output;
  output.open(path,ios_base::out);

  if(result.first==-1 && result.second==-1){
    output<< -1;
    return;
  }
  output<<result.first<< " "<<result.second<<endl;
}