#include "structure.h"

int main() {
  vector<int> number;
  pair<int,int> result;
  int target;
  dataFromFile("../input_1.txt",number,target);
  result = satisfyPair(number,target);
  printResultTo("../output_1.txt",result);
  cout<<"Check output file"<<endl;
  return 0;
}
