
#ifndef DSA_LAB_MIDTERM_EXERCISE1_STRUCTURE_H
#define DSA_LAB_MIDTERM_EXERCISE1_STRUCTURE_H
#include <fstream>
#include <string>
#include <iostream>
#include <vector>
using namespace std;

void dataFromFile(const string &path, vector<int>&number, int &target);

pair<int, int> satisfyPair(const vector<int> &number, const int &target);

void printResultTo(const string &path, const pair<int,int> &result);
#endif
