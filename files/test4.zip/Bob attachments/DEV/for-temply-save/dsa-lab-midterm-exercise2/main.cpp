#include "structure.h"

int main() {
  vector<vector<int>> number = dataFrom("../input_2.txt");
  sort(number);
  printTo("../output_2.txt",number);
  cout<<"Check output file!!"<<endl;
  return 0;
}
