#include "structure.h"
#include <algorithm>
vector<vector<int>> dataFrom(const string &path){
  vector<vector<int>> result;
  ifstream input;
  input.open(path,ios_base::in);
  if(!input.is_open()){
    throw runtime_error("can not open input file!!");
  }
  int row;
  int col;
  input>>row;
  input>>col;
  for(int i = 0; i<row;i++){
    vector<int> temp;
    for(int j = 0; j<col;j++){
      int tempNum;
      input>>tempNum;
      temp.push_back(tempNum);
    }
    result.push_back(temp);
  }
  return result;
}

void sort(vector<vector<int>> &arr){
  for(int i = 0;i<arr[0].size();i++){
    vector<pair<int,int>>index;
    vector<int> value;
    for(int j = 0;j<arr.size();j++){
      int colIndex = j;
      int rowIndex = i;
      while(colIndex<arr[0].size() && rowIndex<arr.size()){
        index.push_back(pair<int,int>(rowIndex,colIndex));
        value.push_back(arr[rowIndex][colIndex]);
        rowIndex++;
        colIndex++;
      }
    }
    std::sort(value.begin(), value.end());
    for(int j = 0; j<value.size();j++){
      arr[index[j].first][index[j].second] = value[j];
    }
  }
}

void printTo(const string &path, const vector<vector<int>>&number){
  ofstream output;
  output.open(path,ios_base::out);
   if(!output.is_open()){
    throw runtime_error("can not open output file!!");
  }
  for (const auto &item : number){
    for (const auto &item2 : item){
      output<<item2<<" ";
    }
    output<<endl;
  }
}

