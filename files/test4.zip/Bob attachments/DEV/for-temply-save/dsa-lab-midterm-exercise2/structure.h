

#ifndef DSA_LAB_MIDTERM_EXERCISE2_STRUCTURE_H
#define DSA_LAB_MIDTERM_EXERCISE2_STRUCTURE_H

#include <vector>
#include <fstream>
#include <string>
#include <iostream>
using namespace std;

vector<vector<int>> dataFrom(const string &path);

void sort(vector<vector<int>> &arr);

void printTo(const string &path, const vector<vector<int>>&number);

#endif
