

#ifndef DEFINE_HEAP_SORT_SORT_H
#define DEFINE_HEAP_SORT_SORT_H
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

void quickSort(int arr[], int low, int high);

void heapSort(int *&arr, int size);

void mergeSort(int *&arr, int left, int right);

void printArray(int *arr, int size);
#endif
