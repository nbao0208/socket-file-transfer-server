#include "sort.h"


int main() {
  int n;
  cout << "Enter number of elements: ";
  cin >> n;

  int* arr = new int[n];
  int* arr2 = new int[n];
  int* arr3 = new int[n];
  srand(time(0));

  for (int i = 0; i < n; i++) {
    arr[i] = rand() % 1000;
    arr2[i] = arr[i];
    arr3[i] = arr[i];
  }

  cout<<"Before sort: "<<endl;
  printArray(arr,n);
  cout<<endl;
  clock_t start = clock();
  quickSort(arr, 0, n - 1);
  clock_t end = clock();

  double time_taken_QuickSort = double(end - start) / double(CLOCKS_PER_SEC);
  cout<<"After quick sort: "<<endl;
  printArray(arr,n);
  cout<<endl;
  cout << "QuickSort Time taken: " << time_taken_QuickSort << " sec" << endl;

  cout<<endl;
  start = clock();
  heapSort(arr2, n);
  end = clock();

  double time_taken_HeapSort = double(end - start) / double(CLOCKS_PER_SEC);
  cout<<"After heap sort: "<<endl;
  printArray(arr2,n);
  cout<<endl;
  cout << "Heap sort time taken: " << time_taken_HeapSort << " sec" << endl;

  cout<<endl;
  start = clock();
  mergeSort(arr3, 0,n-1);
  end = clock();

  double time_taken_MergeSort = double(end - start) / double(CLOCKS_PER_SEC);
  cout<<"After merge sort: "<<endl;
  printArray(arr2,n);
  cout<<endl;
  cout << "Merge sort time taken: " << time_taken_MergeSort << " sec" << endl;


  free(arr);
  free(arr2);
  free(arr3);
  return 0;
}
