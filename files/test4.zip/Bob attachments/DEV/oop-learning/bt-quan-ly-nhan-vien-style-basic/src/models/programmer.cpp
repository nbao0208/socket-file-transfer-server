#include <iostream>
#include "programmer.h"

using namespace std;

float programmer::getOverTime() const {
    return overTime;
}

void programmer::setOverTime() {
    float overTime;
    cout << "Overtime: ";
    cin >> overTime;
    this->overTime = overTime;
}

float programmer::calSalary() {
    return (7 * (this->salaryFactor)) + (0.1 * (this->overTime));
}
