

#ifndef BT_QUAN_LY_NHAN_VIEN_STYLE_BASIC_TESTER_H
#define BT_QUAN_LY_NHAN_VIEN_STYLE_BASIC_TESTER_H
#include "staff.h"

class tester: public staff{
private:
    int error;
public:
    int getError() const;
    void setError();
    float calSalary();
};


#endif
