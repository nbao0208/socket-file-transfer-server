#include <iostream>
#include "designer.h"

using namespace std;

float designer::getBonus() const {
    return bonus;
}

void designer::setBonus() {
    float bonus;
    cout << "Bonus: ";
    cin >> bonus;
    this->bonus = bonus;
}

float designer::calSalary() {
    return (7 * (this->salaryFactor)) + this->bonus;
}
