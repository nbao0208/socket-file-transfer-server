

#ifndef BT_QUAN_LY_NHAN_VIEN_STYLE_BASIC_STAFF_H
#define BT_QUAN_LY_NHAN_VIEN_STYLE_BASIC_STAFF_H

#include <string>
#include <iostream>
using namespace std;

class staff {
protected:
    string name;
    string dob;
    string id;
    string address;
    float salaryFactor;
    string startedDay;
public:
    const string &getName() const;

    void setName(const string &name);

    const string &getDob() const;

    void setDob(const string &dob);

    const string &getId() const;

    void setId(const string &id);

    const string &getAddress() const;

    void setAddress(const string &address);

    float getSalaryFactor() const;

    void setSalaryFactor(float salaryFactor);

    const string &getStartedDay() const;

    void setStartedDay(const string &startedDay);
    void setAllInformation();
    virtual void setOverTime(){
        cout<<"Don't have this feature in this staff";
    }
    virtual void setBonus(){
        cout<<"Don't have this feature in this staff";
    }
    virtual void setError(){
        cout<<"Don't have this feature in this staff";
    }
    virtual float calSalary()=0;
};


#endif
