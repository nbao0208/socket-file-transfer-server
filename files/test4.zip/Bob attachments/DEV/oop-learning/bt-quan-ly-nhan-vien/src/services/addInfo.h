

#ifndef BT_QUAN_LY_NHAN_VIEN_ADDINFO_H
#define BT_QUAN_LY_NHAN_VIEN_ADDINFO_H
#include "../models/personnel/allPersonnel.h"
using namespace std;
class addInfo {
public:
     manager createManager(string name, string id, string dob, string address, float heSoLuong, string startedDay);
    designer createDesigner(string name, string id, string dob, string address, float heSoLuong, string startedDay, float bonus);
    programmer createProgrammer(string name, string id, string dob, string address, float heSoLuong, string startedDay,float overTime );
    tester createTester(string name, string id, string dob, string address, float heSoLuong, string startedDay,int error );

};


#endif //BT_QUAN_LY_NHAN_VIEN_ADDINFO_H
