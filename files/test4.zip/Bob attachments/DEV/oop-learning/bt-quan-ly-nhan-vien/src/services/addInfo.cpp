

#include "addInfo.h"

using namespace std;

manager addInfo::createManager(std::string name, std::string id, std::string dob, std::string address, float heSoLuong,
                               std::string startedDay) {
    manager *myManager = new manager;
    myManager->setName(name);
    myManager->setId(id);
    myManager->setDob(dob);
    myManager->setAddress(address);
    myManager->setHeSoLuong(heSoLuong);
    myManager->setStartedDay(startedDay);
    return *myManager;
}

designer
addInfo::createDesigner(std::string name, std::string id, std::string dob, std::string address, float heSoLuong,
                        std::string startedDay, float bonus) {
    designer *myDesigner = new designer;
    myDesigner->setName(name);
    myDesigner->setId(id);
    myDesigner->setDob(dob);
    myDesigner->setAddress(address);
    myDesigner->setHeSoLuong(heSoLuong);
    myDesigner->setStartedDay(startedDay);
    myDesigner->setBonus(bonus);
    return *myDesigner;
}

programmer
addInfo::createProgrammer(std::string name, std::string id, std::string dob, std::string address, float heSoLuong,
                          std::string startedDay, float overTime) {
    programmer *myProgrammer = new programmer;
    myProgrammer->setName(name);
    myProgrammer->setId(id);
    myProgrammer->setDob(dob);
    myProgrammer->setAddress(address);
    myProgrammer->setHeSoLuong(heSoLuong);
    myProgrammer->setStartedDay(startedDay);
    myProgrammer->setOverTime(overTime);
    return *myProgrammer;
}

tester addInfo::createTester(std::string name, std::string id, std::string dob, std::string address, float heSoLuong,
                             std::string startedDay, int error) {
    tester *myTester = new tester;
    myTester->setName(name);
    myTester->setId(id);
    myTester->setDob(dob);
    myTester->setAddress(address);
    myTester->setHeSoLuong(heSoLuong);
    myTester->setStartedDay(startedDay);
    myTester->setError(error);
    return *myTester;
}
