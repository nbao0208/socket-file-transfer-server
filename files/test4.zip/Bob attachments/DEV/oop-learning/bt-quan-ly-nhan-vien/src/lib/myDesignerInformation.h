

#ifndef BT_QUAN_LY_NHAN_VIEN_MYDESIGNERINFORMATION_H
#define BT_QUAN_LY_NHAN_VIEN_MYDESIGNERINFORMATION_H

#include "../models/personnel/staff.h"
#include "../services/addInfo.h"
#include <vector>

void myDesignerInformation(vector<staff *> &personnel, addInfo addInfo);

#endif
