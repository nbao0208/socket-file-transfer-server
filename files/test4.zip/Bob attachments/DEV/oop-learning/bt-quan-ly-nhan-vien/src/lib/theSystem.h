

#ifndef BT_QUAN_LY_NHAN_VIEN_THESYSTEM_H
#define BT_QUAN_LY_NHAN_VIEN_THESYSTEM_H

#include "../models/personnel/staff.h"
#include <vector>

void mySystem(vector<staff *> &personnel);

#endif //BT_QUAN_LY_NHAN_VIEN_THESYSTEM_H
