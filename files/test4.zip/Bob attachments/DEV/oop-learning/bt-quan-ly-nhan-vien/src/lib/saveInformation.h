

#ifndef BT_QUAN_LY_NHAN_VIEN_SAVEINFORMATION_H
#define BT_QUAN_LY_NHAN_VIEN_SAVEINFORMATION_H
#include <string>
using namespace std;

void saveInfo(string &name, string &id, string &dob, string &address, float &heSoLuong, string &startedDay);

#endif
