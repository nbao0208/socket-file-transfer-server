#include <iostream>
#include <vector>

using namespace std;

//vector<int> twoSum(vector<int> &nums, int target) {
//    vector<int> temp;
//    for (int i = 0; i < nums.size(); i++) {
//        for (int j = 1; j <= nums.size() - i - 1; ++j) {
//            if (nums[i] + nums[i + j] == target) {
//                temp.push_back(i);
//                temp.push_back(i + j);
//                return temp;
//            }
//        }
//    }
//    return temp;
//}
vector<int> twoSum(vector<int> &nums, int target) {
   vector <int> temp;
    for (int i = 0; i < nums.size(); i++) {

    }
}

int main() {

    return 0;
}
