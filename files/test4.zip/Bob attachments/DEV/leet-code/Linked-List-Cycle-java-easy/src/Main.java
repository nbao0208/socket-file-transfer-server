import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

    public static class ListNode {
        int val;
        ListNode next;

        ListNode(int x) {
            val = x;
            next = null;
        }
    }


    public static boolean isExistingIn(List<ListNode> nodes, ListNode head) {
        for (ListNode node : nodes) {
            if (head == node) {
                return true;
            }
        }
        return false;
    }

    public boolean hasCycle(ListNode head) {
        if (head == null) {
            return false;
        }
        List<ListNode> nodes = new ArrayList<>();
        nodes.add(head);
        head = head.next;
        while (head != null) {
            if (!isExistingIn(nodes, head)) {
                nodes.add(head);
                head = head.next;
            } else {
                return true;
            }
        }
        return false;
    }
}