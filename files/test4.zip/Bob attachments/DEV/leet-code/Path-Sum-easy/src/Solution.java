import java.beans.Introspector;
import java.util.ArrayList;
import java.util.List;

public class Solution {
    public void addValue(TreeNode root, List<String> value) {
        if (root != null) {
            addValue(root.left, value);
            addValue(root.right, value);
            if (root.left == null && root.right == null) {
                value.add(String.valueOf(root.val) + "*");
            } else {
                value.add(String.valueOf(root.val));
            }
        }
    }

    public boolean hasPathSum(TreeNode root, int targetSum) {
        List<String> treeValues = new ArrayList<>();
        addValue(root, treeValues);
        List<Integer> indexOfLeafs = new ArrayList<>();
        for (String value : treeValues) {
            if (value.contains("*")) {
                indexOfLeafs.add(treeValues.indexOf(value));
            }
        }
        List<Integer> leftLeafs = new ArrayList<>();
        List<Integer> rightLeafs = new ArrayList<>();
        for (int i = 0; i < indexOfLeafs.size() - 1; i++) {
            if (indexOfLeafs.get(i + 1) - indexOfLeafs.get(i) != 1) {
                leftLeafs = indexOfLeafs.subList(0, i+1);
                rightLeafs = indexOfLeafs.subList(i + 1, indexOfLeafs.size());
                break;
            }
        }
        int compareWithTarget = 0;
        int sumBetweenInLeft = 0;
        int sumBetweenInRight = 0;
        for (int i = leftLeafs.get(leftLeafs.size() - 1) + 1; i <= rightLeafs.get(0) - 1; i++) {
            sumBetweenInLeft += Integer.parseInt(treeValues.get(i));
        }

        for (int i = rightLeafs.get(rightLeafs.size() - 1) + 1; i <= treeValues.size() - 2; i++) {
            sumBetweenInRight += Integer.parseInt(treeValues.get(i));
        }

        for (int index : leftLeafs) {
            compareWithTarget = sumBetweenInLeft + (int) (treeValues.get(index).charAt(0)) + root.val;
            if (compareWithTarget == targetSum) {
                return true;
            }
        }
        for (int index : rightLeafs) {
            compareWithTarget = sumBetweenInRight + (int) (treeValues.get(index).charAt(0)) + root.val;
            if (compareWithTarget == targetSum) {
                return true;
            }
        }
        return false;
    }
}
