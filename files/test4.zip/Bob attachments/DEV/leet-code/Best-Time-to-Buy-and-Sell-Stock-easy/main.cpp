#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int maxProfit(vector<int> &prices) {
    if (prices.size() == 1 || prices.empty()) {
        return 0;
    }
    int maxProfit = -prices[0] + *max_element(prices.begin() + 1, prices.end());
    if (maxProfit < 0) {
        maxProfit = 0;
    }
    for (int i = 1; i < prices.size() - 1; i++) {
        if (maxProfit < -prices[i] + *max_element(prices.begin() + i + 1, prices.end())) {
            maxProfit = -prices[i] + *max_element(prices.begin() + i + 1, prices.end());
        }
    }
    return maxProfit;
}

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
