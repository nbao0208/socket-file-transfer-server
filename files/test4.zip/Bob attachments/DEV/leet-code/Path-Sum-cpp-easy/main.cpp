#include <iostream>
#include<vector>

using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;

    TreeNode() : val(0), left(nullptr), right(nullptr) {}

    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}

    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};

void addLeafs(TreeNode *root, vector<TreeNode *> &leafs) {
    if (root != nullptr) {
        if (root->left == nullptr && root->right == nullptr) {
            leafs.push_back(root);
        }
        addLeafs(root->left, leafs);
        addLeafs(root->right, leafs);
    }
}

void pathSumRootToLeaf(TreeNode *root, TreeNode *leaf, int &sum) {
    if (root == nullptr) {
        return;
    }
    sum += root->val;
    if (root->left == leaf || root->right == leaf) {
        sum += leaf->val;
    }
    pathSumRootToLeaf(root->right, leaf, sum);
    pathSumRootToLeaf(root->left, leaf, sum);
}

bool hasPathSum(TreeNode *root, int targetSum) {

}

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
