#include <iostream>
#include <string>

using namespace std;

bool isAllRoundBracket(string roundBracket) {
    if (roundBracket[0] != '(') {
        return false;
    }
//    for (int i = 0; i < roundBracket.size(); i++) {
//        if ()
//    }
}

bool isValid(string s) {
    if ((s.size()) % 2 != 0 || s.size() == 0) {
        return false;
    }
    for (char i: s) {
        if (i=='(')
    }


}

int main() {
    char test = '}';
    cout << int(test);
    return 0;
}
