
import java.util.Map;
import java.util.TreeMap;

public class Main {
    public static void main(String[] args) {
        System.out.println(isValid("({{{{}}}))"));
    }


    public static class helpIsValid {
        public static final Map<Character, Character> rules = new TreeMap<>();

        static {
            rules.put('{', '}');
            rules.put('[', ']');
            rules.put('(', ')');
        }
    }

    public static boolean isValid(String s) {
        if (s.isEmpty()) {
            return true;
        }
        if (s.length() % 2 != 0) {
            return false;
        }
        if (s.charAt(0) == '}' || s.charAt(0) == ']' || s.charAt(0) == ')') {
            return false;
        }
        int index = s.indexOf(helpIsValid.rules.get(s.charAt(0)));
        while (index != -1) {
            if (isValid(s.substring(1, index))) {
                if (index == s.length() - 1) {
                    return true;
                }
                return isValid(s.substring(index + 1));
            }
            index = s.indexOf(helpIsValid.rules.get(s.charAt(0)), index + 1);
        }
        return false;
    }

}