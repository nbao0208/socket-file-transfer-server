public class solution {

}
