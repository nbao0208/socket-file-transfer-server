#include <iostream>
#include<vector>

using namespace std;

unsigned long long combination(int n, int k) {
    if (k > n - k) {
        k = n - k;
    }

    unsigned long long result = 1;

    for (int i = 0; i < k; ++i) {
        result *= (n - i);
        result /= (i + 1);
    }

    return result;
}


vector<int> getRow(int rowIndex) {
    if (rowIndex == 0) {
        return {1};
    }
    vector<int> row;
    row.reserve(rowIndex + 1);
    for (int i = 0; i < rowIndex + 1; i++) {
        if (i == 0 || i == rowIndex) {
            row.push_back(1);
        } else {
            row.push_back((int) combination(rowIndex, i));
        }
    }
    return row;
}

int main() {

    for (int i: getRow(25)) {
        cout << i << " ";
    }

    return 0;
}
