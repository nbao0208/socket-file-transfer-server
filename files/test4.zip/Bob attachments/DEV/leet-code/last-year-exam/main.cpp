#include <iostream>
#include <vector>
using namespace std;

struct productRelation{
    int index;
    vector<productRelation*> possibleIndex;
};
void printAllGroceries(int price[], int size, int money){
    for (int i = 0; i < size; i++) {

    }
}
int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
