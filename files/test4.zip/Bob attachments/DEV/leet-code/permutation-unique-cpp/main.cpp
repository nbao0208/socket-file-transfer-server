#include <iostream>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

void helpPermute(map<int, bool> &nums, vector<vector<int>> &saveNum, vector<int> &helpSave) {
    for (auto &item: nums) {
        if (!item.second) {
            helpSave.push_back(item.first);
            item.second = true;
            if (nums.size() == helpSave.size()) {
                saveNum.push_back(helpSave);
                item.second = false;
                helpSave.pop_back();
                continue;
            }
            helpPermute(nums, saveNum, helpSave);
            helpSave.pop_back();
            item.second = false;
        }
    }
}

map<int, bool> generateToMapFrom(const vector<int> &nums) {
    map<int, bool> result;
    for (const auto &item: nums) {
        result.insert(pair<int, bool>(item, false));
    }
    return result;
}

bool isTheSame(const vector<int> &first, const vector<int> &second) {
    for (int i = 0; i < first.size(); i++) {
        if (first[i] != second[i]) {
            return false;
        }
    }
    return true;
}

void filterVector(vector<vector<int>> &nums) {
//    sort(nums.begin(), nums.end());
//    nums.erase(unique(nums.begin(), nums.end()),nums.end());
    sort(nums.begin(), nums.end());
    nums.erase(std::unique(nums.begin(), nums.end(), isTheSame),nums.end());
}


vector<vector<int>> permuteUnique(vector<int> &nums) {
    vector<vector<int>> result;
    vector<int> help;
    map<int, bool> numsWithFlag = generateToMapFrom(nums);
    helpPermute(numsWithFlag, result, help);
    filterVector(result);
    return result;
}

int main() {
    vector<int> nums;
    nums.push_back(1);
    nums.push_back(1);
    nums.push_back(2);
    filterVector(nums);
    for (const auto &item: nums){
        cout<<item<<" ";
    }
    return 0;
}
