# MYSQL DOCS
#### Start:
```bash
docker-compose up -d
```

#### Turn off:
```bash
docker-compose down
```

#### Delete all content in the pass:
```bash
docker-compose down -v
```

#### Restart:
```bash
docker-compose down && docker-compose up -d
```

#### Note:
- Change credential in docker-compose file and restart.