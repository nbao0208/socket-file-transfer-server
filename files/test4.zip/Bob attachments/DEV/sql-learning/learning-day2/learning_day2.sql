CREATE DATABASE forDay2
CHARACTER SET "utf8mb4"
COLLATE "utf8mb4_general_ci";

SHOW DATABASES;

CREATE TABLE student(
  name varchar(40),
  dob date,
  mssv varchar(40)
);

CREATE TABLE student_2 AS
    SELECT name, dob
FROM student;

DROP TABLE IF EXISTS student_2;

TRUNCATE TABLE student;

ALTER TABLE student
ADD email VARCHAR(50);

ALTER TABLE student
DROP COLUMN mssv;


ALTER TABLE student
MODIFY COLUMN email VARCHAR(60);