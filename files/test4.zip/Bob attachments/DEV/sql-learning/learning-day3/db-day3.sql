CREATE DATABASE db_day3;
USE db_day3;
SHOW DATABASES;

DROP TABLE student;
CREATE TABLE student(
    mssv VARCHAR(50) UNIQUE NOT NULL ,
    hoDem VARCHAR(50) NOT NULL ,
    name VARCHAR(20) NOT NULL ,
    dob date NOT NULL ,
    yearStarted year NOT NULL
);

ALTER TABLE student
MODIFY COLUMN name VARCHAR(50) UNIQUE NOT NULL;

ALTER TABLE student
MODIFY COLUMN name VARCHAR(50) NOT NULL ;

DELETE FROM student
WHERE name = 'Nguyen Van B';

SELECT *FROM student;

SELECT name FROM student;


SELECT *FROM student WHERE (yearStarted>=2022);

SELECT name FROM student WHERE (yearStarted=2023);

SELECT *FROM  student WHERE (hoDem='Nguyen' AND yearStarted>=2021);

SELECT *FROM  student ORDER BY yearStarted ASC ;

ALTER TABLE student
ADD primarySchool VARCHAR(70) NULL ;

SELECT name FROM student WHERE (student.primarySchool IS NULL);

SELECT * FROM student WHERE (student.primarySchool IS NOT NULL);

UPDATE student
SET yearStarted = yearStarted+1
WHERE (student.primarySchool IS NOT NULL );

DELETE FROM student WHERE (student.primarySchool IS NULL);

SELECT *FROM student WHERE (hoDem='Nguyen') LIMIT 2;

-- Bản chất của dòng này chính là lấy thằng max trong đống student ra, cần lấy trong một
-- tập điều kiện nào đó thì ghi vô where gì gì đó.
SELECT MAX(yearStarted) FROM student;

SELECT * FROM student WHERE (yearStarted = (SELECT MAX(yearStarted) FROM student WHERE hoDem='Nguyen'));


-- Câu lệnh min max còn can thiệp được vào những thành phần nếu mình dùng hàm liên quan
-- nên là cần cái gì thì research rồi làm thôi
SELECT *FROM  student WHERE (DAY(dob)=(SELECT  MIN(DAY(dob)) FROM student));

SELECT COUNT(*) FROM student WHERE yearStarted=2021;

SELECT AVG(yearStarted) FROM student WHERE hoDem='Nguyen';

SELECT SUM(yearStarted) FROM student;

-- BETWEEN thì nó như kẹp khoản của một giá trị số nào đó hay ngày tháng năm
SELECT * FROM student WHERE (yearStarted BETWEEN 2021 AND 2025);

SELECT * FROM student WHERE (dob BETWEEN '2002-01-01' AND '2005-06-06');

-- Lấy min của ngày tháng năm thì sẽ lấy ngày tháng năm sớm nhất(lâu nhất)
SELECT * FROM student WHERE (dob = (SELECT MIN(dob) FROM student));
-- Lấy max của ngày tháng năm thì sẽ lấy ngày tháng năm mới nhất(trễ nhất)
SELECT * FROM student WHERE (dob = (SELECT MAX(dob) FROM student));

-- % là đại diện cho một hoặc nhiều kí tự trước hay sau n, tuỳ vào chỗ mình đặt dấu %
-- _ là đại diện cho một kí tự trước hay sau n, tuỳ vào chỗ mình đặt dấu _
SELECT * FROM  student WHERE (name LIKE '%n');

SELECT * FROM  student WHERE (name LIKE 'V%n'); 