#include <iostream>
#include <map>
#include <string>
#include <list>

using namespace std;

int main() {
    map<string, list<string>> genshinCharacterInformation;
    char ans = 'y';
    while (ans == 'y') {
        char ans2 = 'y';
        string characterName;
        list<string> characterSkills;
        cout << "Write character's name: ";
        getline(cin, characterName);
        while (ans2 == 'y') {
            string temp;
            cout << "Add skill: ";
            getline(cin, temp);
            characterSkills.push_back(temp);
            cout << "Again: ";
            cin >> ans2;
            cin.ignore();
        }
        genshinCharacterInformation.insert(pair<string, list<string>>(characterName, characterSkills));
        cout << "Again: ";
        cin >> ans;
        cin.ignore();
    }
    for (auto pair: genshinCharacterInformation) {
        cout << pair.first << endl;
        cout << "With the skill is: ";
        for (auto skill: pair.second) {
            cout << skill << " - ";
        }
        cout << endl;
    }
    return 0;
}
