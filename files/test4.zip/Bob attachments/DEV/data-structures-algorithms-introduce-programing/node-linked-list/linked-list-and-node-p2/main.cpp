#include <iostream>

using namespace std;

struct node {
    int data;
    node *pNext;
};

class list {
public:
    node *head = new node();
    node *tail = new node();

    void sayHi() {
        cout << "hi" << endl;
    }

};

void addInTheFront(list &lst, int value) {
    if (lst.head->data == NULL) {
        lst.head->data = value;
        lst.head->pNext = lst.tail;
        lst.tail->pNext = nullptr;
    } else {
        node *newNode = new node();
        newNode->data = value;
        newNode->pNext = lst.head;
        lst.head = newNode;
    }
}

void add(list &lst, int value) {
    if (lst.head->data == NULL) {
        lst.head->data = value;
        lst.head->pNext = lst.tail;
        lst.tail->pNext = nullptr;
    } else if (lst.tail->data == NULL) {
        lst.tail->data = value;
    } else {
        node *newNode = new node();
        newNode->data = value;
        newNode->pNext = nullptr;
        lst.tail->pNext = newNode;
        lst.tail = newNode;
    }
}

void addAtTheIndex(list &lst, int index, int value) {
    node *newNode = new node();
    newNode->data = value;
    node *temp = lst.head;
    for (int i = 0; i < index - 1; i++) {
        temp = temp->pNext;
    }
    node *secondTemp = temp->pNext;
    newNode->pNext = secondTemp;
    temp->pNext = newNode;
}

void printList(list lst) {
    if (lst.head->data == NULL) {
        cout << "list is empty";
    } else {
        node *printNode = lst.head;
        while (printNode != nullptr) {
            cout << printNode->data << " ";
            printNode = printNode->pNext;
        }
    }
}


int size(list lst) {
    if (lst.head == nullptr) {
        return 0;
    } else {
        int count = 0;
        node *forSize = lst.head;
        while (forSize != nullptr) {
            count++;
            forSize = forSize->pNext;
        }
        return count;
    }
}

void eraseList(list lst) {
    int count = 0;
    node *temp = lst.head;
    delete lst.head;
    while (count < size(lst)) {
        node *current = temp;
        delete temp;
        current = current->pNext;
        count++;
    }
}

int main() {
    list lst;
    lst.sayHi();
    add(lst, 1);
    add(lst, 2);
    printList(lst);
    cout << endl;
    cout << size(lst);
    eraseList(lst);
    return 0;
}
