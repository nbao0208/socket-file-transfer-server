#include <iostream>

using namespace std;

struct node {
    int data;
    node *pNext;
};

class list {
public:
    node *head;
    node *tail;

    void generateList() {
        head->pNext = tail;
        tail->pNext = NULL;
        head->data = NULL;
    }

    void insertValue(int value) {
        node *newNode = new node();
        newNode->data = value;
        newNode->pNext = NULL;
        tail->pNext = newNode;
        tail = newNode;
    }

    void printList() {
        while (head->pNext != NULL) {
            if (head->data != NULL) {
                cout << head->data << " ";
            }
            head = head->pNext;
        }
    }
};

void printList(node *head);

void insertNewValueAtTheFront(node **head, int value) {
    node *newNode = new node();
    newNode->data = value;
    newNode->pNext = *head;
    *head = newNode;
}

void insertNewValueAtTheEnd(node **tail, int value) {
    node *newNode = new node();
    newNode->data = value;
    newNode->pNext = NULL;
    if (*tail == NULL) {
        *tail = newNode;
    } else {
        (*tail)->pNext = newNode;
        *tail = newNode;
    }
}

void insertNewValueAtTheGivenIndex(node **head, int index, int value) {
    if (index == 0) {
        insertNewValueAtTheFront(head, value);
    } else {
        node *indexMinusOne = *head;
        for (int i = 0; i < index - 1; i++) {
            indexMinusOne = (indexMinusOne)->pNext;
        }
        node *myIndex = indexMinusOne->pNext;
        node *newNode = new node();
        newNode->data = value;
        newNode->pNext = myIndex;
        indexMinusOne->pNext = newNode;
    }
}

int main() {
    node *head = new node();
    node *second = new node();
    node *tail = new node();
    head->data = 1;
    head->pNext = second;
    second->data = 2;
    second->pNext = tail;
    tail->data = 3;
    tail->pNext = NULL;
    insertNewValueAtTheFront(&head, -1);
    insertNewValueAtTheEnd(&tail, -2);
    insertNewValueAtTheGivenIndex(&head, 1, 5);
    printList(head);
    return 0;
}

void printList(node *head) {
    while (head != NULL) {
        cout << head->data << " ";
        head = head->pNext;
    }
}
