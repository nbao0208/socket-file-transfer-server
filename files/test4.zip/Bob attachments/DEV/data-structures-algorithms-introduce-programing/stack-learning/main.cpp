#include <iostream>
#include <stack>

using namespace std;

void printStack(stack<int> myStack) {
    while (!myStack.empty()) {
        cout << myStack.top() << " ";
        myStack.pop();
    }
}

int main() {
    stack<int> number;
    number.push(1);
    number.push(2);
    if (number.empty()) {
        cout << "Stack is empty" << endl;
    } else {
        cout << "Stack is not empty" << endl;
        cout << "The stack's size is " << number.size() << endl;
        cout << "The stack element: ";
        printStack(number);
    }
    cout << endl;
    cout << number.top();
    return 0;
}
