using namespace std;

#ifndef B_TREE_LEARNING_BTREE_SEARCHING_H
#define B_TREE_LEARNING_BTREE_SEARCHING_H
struct node {
    int data;
    node *p_left;
    node *p_right;
};


#endif //B_TREE_LEARNING_BTREE_SEARCHING_H
