#include<iostream>

using namespace std;

struct node {
    int data;
    node *p_left;
    node *p_right;
};

class btree {
private:
    node *root;
public:
    btree() {
        root = nullptr;
    }

    void addData(int data) {
        node *newNode = new node();
        newNode->data = data;
        newNode->p_left = nullptr;
        newNode->p_right = nullptr;
        if (root == nullptr) {
            root = newNode;
        } else {
            node *temp = root;
//            while (temp != nullptr) {
//                if (data < temp->data) {
//                    temp = temp->p_left;
//                } else {
//                    temp = temp->p_right;
//                }
//            }
//            temp = newNode;
// this is an error code, the reason is that temp is just pointer to root, so if you place temp = newNode, it just change the value of temp,
// because temp don't had connected to
// root anymore, but if we give temp.pleft or right, it will change the root to,
// because you have the connection to its pointer left or right so if you change it it will be damage to tree structure


            while (temp != nullptr) {
                if (data < temp->data) {
                    if (temp->p_left == nullptr) {
                        temp->p_left = newNode;
                        break;
                    } else {
                        temp = temp->p_left;
                    }
                } else {
                    if (temp->p_right == nullptr) {
                        temp->p_right = newNode;
                        break;
                    } else {
                        temp = temp->p_right;
                    }
                }
            }

        }
    }

    void printNode(node *myNode) {
        if (myNode != nullptr) {
            printNode(myNode->p_left);//left
            cout << myNode->data << " ";//node
            printNode(myNode->p_right);//right
        }
    }

    void printTree() {
        if (root == nullptr) {
            cout << "Tree is empty" << endl;
        } else {
            node *temp = root;
            printNode(temp);
            cout << endl;
        }
    }

    int size(node *myNode) {
        if (myNode == nullptr) {
            return 0;
        } else {
            return 1 + size(myNode->p_right) + size(myNode->p_left);
        }
    }

    int minValue(node *myNode) {
        if (myNode->p_left == nullptr) {
            return myNode->data;
        }
        return minValue(myNode->p_left);
    }


    int valueOfNode(node* myNode){

    }
    bool isIdentical(node *root1, node *root2) {
        if (size(root1) != size(root2)) {
            return false;
        }



    }

    node *getRoot() {
        return root;
    }
};


int main() {
    btree *myTree = new btree();
    myTree->addData(5);
    myTree->addData(1);
    myTree->addData(2);
    myTree->addData(-2);
    myTree->addData(6);
    myTree->addData(7);
    myTree->printTree();
    cout << endl;
    cout << myTree->size(myTree->getRoot()) << endl;
    cout << myTree->minValue(myTree->getRoot());
    delete myTree;
    return 0;
}