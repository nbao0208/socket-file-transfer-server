#include <iostream>

using namespace std;

void swapNumber(int &num1, int &num2) {
    num1 = num1 + num2;
    num2 = num1 - num2;
    num1 = num1 - num2;
}

void selectionSort(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        int min = i;
        for (int j = i + 1; j < size; j++) {
            if (arr[j] <= arr[min]) {
                min = j;
            }
        }
        if (min != i) {
            swapNumber(arr[i], arr[min]);
        }

    }
}

int main() {
    int arr[] = {2, 3, 1, 4, 8, 7};
    selectionSort(arr, (sizeof(arr)) / sizeof(arr[0]));
    for (int i: arr) {
        cout << i << " ";
    }
    return 0;
}
// this case has the complication of algorithm is O(n^2)
