#include <iostream>

using namespace std;

void swapNumber(int &num1, int &num2) {
    num1 = num1 + num2;
    num2 = num1 - num2;
    num1 = num1 - num2;
}

void insertionSort(int arr[], int size) {
    for (int i = 1; i < size; i++) {
        for (int j = i; j >=0 ; j--) {
            if (arr[j]>=arr[j-1]){
                break;
            }else{
                swapNumber(arr[j],arr[j-1]);
            }
        }
    }
}

int main() {
    int arr[] = {1, 3, 5, 6, 2, 10, 0};
    insertionSort(arr, (sizeof(arr) / sizeof(arr[0])));
    for (int i: arr) {
        cout << i << " ";
    }
    return 0;
}

// the worst case has O(n^2)
// the best case has O(n)