#include <iostream>

using namespace std;

void swapNumber(int &num1, int &num2) {
    num1 = num1 + num2;
    num2 = num1 - num2;
    num1 = num1 - num2;
}

void shellSort(int arr[], int size) {
    int distance = 8;
    while (true) {
        if (distance == 0) {
            break;
        }
        if (distance % 2 == 0 || distance % 3 == 0 || distance == 1) {
            for (int i = 0; i <= size - 1 - distance; i++) {
                if (arr[i + distance] < arr[i]) {
                    swapNumber(arr[i + distance], arr[i]);
                }
            }
        }

        distance--;
    }
}

int main() {
    int arr[] = {81, 94, 11, 96, 12, 35, 17, 95, 28, 58, 41, 75, 15};
    shellSort(arr, sizeof(arr) / sizeof(arr[0]));
    for (int i: arr) {
        cout << i << " ";
    }
    return 0;
}

// this case has the complication algo --> depend on the size of the array and the effective distance that you choosed