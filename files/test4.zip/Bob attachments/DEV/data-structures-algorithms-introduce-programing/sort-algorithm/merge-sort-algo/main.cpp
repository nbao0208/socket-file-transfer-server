#include <iostream>
#include <vector>
using namespace std;

void swapNumber(int &num1, int &num2) {
    num1 = num1 + num2;
    num2 = num1 - num2;
    num1 = num1 - num2;
}

void mergeArray(int arr1[], int arr2[]){


}
void mergeSort(int arr[], int size){

}
int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
