#include <iostream>

using namespace std;

struct node {
    int data;
    node *left;
    node *right;

    explicit node(int value) {
        data = value;
        left = nullptr;
        right = nullptr;
    }

    explicit node() {
        data = 0;
        left = nullptr;
        right = nullptr;
    }

    explicit node(int value, node *forRight, node *forLeft) {
        data = value;
        left = forLeft;
        right = forRight;
    }
};

void addValue(node *&myTree, int value) {
    if (myTree == nullptr) {
        myTree = new node(value);
    } else {
        if (value > myTree->data) {
            addValue(myTree->right, value);
        } else {
            addValue(myTree->left, value);
        }
    }
}

void addValue_PostOrder(node *myTree, vector<int> &value) {
    if (myTree != nullptr) {
        addValue_PostOrder(myTree->left, value);
        addValue_PostOrder(myTree->right, value);
        value.push_back(myTree->data);
    }
}

void printTree(const vector<int> &value) {
    if (value.empty()) {
        cout << "Tree is empty";
    } else {
        for (int i: value) {
            cout << i << " ";
        }
    }
}

int heightOfTree(node *myTree) {
    if (myTree == nullptr) {
        return 0;
    }
    return 1 + max(heightOfTree(myTree->left), heightOfTree(myTree->right));
}

int heightOfTree_HelpCheckBBT(node *myTree) {
    if (myTree == nullptr) {
        return 0;
    }
    if (heightOfTree_HelpCheckBBT(myTree->left) == -1) {
        return -1;
    }
    if (heightOfTree_HelpCheckBBT(myTree->right) == -1) {
        return -1;
    }
    if (heightOfTree_HelpCheckBBT(myTree->left) - heightOfTree_HelpCheckBBT(myTree->right) > 1) {
        return -1;
    }
    return 1 + max(heightOfTree_HelpCheckBBT(myTree->left), heightOfTree_HelpCheckBBT(myTree->right));
}

bool checkBBT_BigO_N(node *myTree) {
    return heightOfTree_HelpCheckBBT(myTree) != -1;
}

bool check_Balanced_BT(node *myTree) {
    if (myTree == nullptr) {
        return true;
    }
    if (abs(heightOfTree(myTree->left) - heightOfTree(myTree->right)) > 1) {
        return false;
    }
    bool checkLeft = check_Balanced_BT(myTree->left);
    bool checkRight = check_Balanced_BT(myTree->right);
    if (checkLeft && checkRight) {
        return true;
    }
    return false;
}

int main() {
    node *myTree = new node(20);
    addValue(myTree, 19);
    addValue(myTree, 25);
    addValue(myTree, 24);
    addValue(myTree, 26);
    vector<int> value;
    addValue_PostOrder(myTree, value);
    printTree(value);
    cout << endl << "Tree's height: " << heightOfTree(myTree);
    if (checkBBT_BigO_N(myTree)) {
        cout << endl << "It's a balanced BT";
    } else {
        cout << endl << "It's not a balanced BT";
    }
    delete myTree;
    return 0;
}
