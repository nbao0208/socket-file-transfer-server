#include <iostream>

using namespace std;
struct node {
    int data;
    node *pNext;
};

class linkedList {
private:
    node *head;
    node *tail;
public:
    linkedList() : head(nullptr), tail(nullptr) {}

    void addNode(int data) {
        node *newNode = new node();
        newNode->data = data;
        newNode->pNext = nullptr;
        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        } else {
            tail->pNext = newNode;
            tail = newNode;
        }

    }

    void printList() {
        node *temp = head;
        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->pNext;
        }
    }

};
//void addNode(node *myNode, int data) {
//    if (myNode == nullptr) {
//        myNode->data = data;
//        myNode->pNext = nullptr;
//    } else {
//        node *newNode = new node();
//        newNode->data = data;
//        newNode->pNext = nullptr;
//        myNode->pNext = newNode;
//        newNode = myNode;
//    }
//}
//
//void printNode(node *myNode) {
//    node *temp = myNode;
//    while (temp != nullptr) {
//        cout << temp->data << " ";
//        temp = temp->pNext;
//    }
//}

int main() {
    linkedList *nums = new linkedList();
    nums->addNode(1);
    nums->addNode(2);
    nums->addNode(3);
    nums->printList();

    return 0;
}
