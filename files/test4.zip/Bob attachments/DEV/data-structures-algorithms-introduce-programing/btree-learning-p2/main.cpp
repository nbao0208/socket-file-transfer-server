#include <iostream>

#include <vector>

#include<queue>

using namespace std;

struct node {
    int data;
    struct node *left;
    struct node *right;

    explicit node(int value) {
        data = value;
        left = nullptr;
        right = nullptr;
    }
};

void addNode(node *&root, int data) {
    if (root == nullptr) {
        node *newNode = new node(data);
        root = newNode;
    } else {
        if (data < root->data) {
            addNode(root->left, data);
        } else {
            addNode(root->right, data);
        }
    }
}

void printTree(node *root) {
    if (root != nullptr) {
        cout << root->data << " ";
        printTree(root->left);
        printTree(root->right);
    }
}

vector<vector<int>> myTreeValue_BFS(node *root) {
    vector<vector<int>> result;
    if (root == nullptr) {
        return result;
    }
    queue<node *> myNode;
    myNode.push(root);
    while (!myNode.empty()) {
        int execution = myNode.size();
        vector<int> level;
        for (int i = 0; i < execution; i++) {
            level.push_back(myNode.front()->data);
            if (myNode.front()->left != nullptr) {
                myNode.push(myNode.front()->left);
            }
            if (myNode.front()->right != nullptr) {
                myNode.push(myNode.front()->right);
            }
            myNode.pop();
        }
        result.push_back(level);
    }
    return result;
}

void BFSprint(vector<vector<int>> myNode) {
    if (myNode.empty()) {
        cout << "Tree is empty";
        return;
    }
    for (auto vec: myNode) {
        for (int i: vec) {
            cout << i << " ";
        }
    }
}

int main() {
    node *myTree = new node(1);
    addNode(myTree, 2);
    addNode(myTree, 3);
    BFSprint(myTreeValue_BFS(myTree));
    delete myTree;
    return 0;
}
