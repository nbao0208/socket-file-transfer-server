#include <iostream>
#include <queue>
#include <string>

using namespace std;


void printTask(queue<string> task) {
    int index = 1;
    while (!task.empty()) {
        cout << index << ". " << task.front() << endl;
        task.pop();
    }
    index++;
}

int main() {
    queue<string> taskInDay;
    char ans = 'y';
    for (int i = 1; i < i + 1; i++) {
        if (!(ans == 'y' || ans == 'Y')) {
            break;
        }
        if (i == 1) {
            cout << "Add your first task: ";
        } else if (i == 2) {
            cout << "Add your second task: ";
        } else if (i == 3) {
            cout << "Add your third task: ";
        } else {
            cout << "Add your " << i << "th task: ";
        }

        string temp;
        getline(cin, temp);
        taskInDay.push(temp);
        cout << "Do you want to add more tasks(y for yes and n for no): ";
        cin >> ans;
        cin.ignore();
        cout << endl;
    }
    cout << "Your task in day is: " << endl;
    printTask(taskInDay);

    return 0;
}
