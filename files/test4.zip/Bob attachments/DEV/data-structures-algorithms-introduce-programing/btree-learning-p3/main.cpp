#include <iostream>
#include<stack>
#include<vector>

using namespace std;

struct node {
    int data;
    struct node *left;
    struct node *right;

    explicit node(int value) {
        data = value;
        left = nullptr;
        right = nullptr;
    }

    node() {
        data = 0;
        left = nullptr;
        right = nullptr;
    }

    node(int data, node *left, node *right) {
        this->data = data;
        this->left = left;
        this->right = right;
    }

};

void addNode(node *&root, int value) {
    if (root == nullptr) {
        root = new node(value);
    } else {
        if (value < root->data) {
            addNode(root->left, value);
        } else {
            addNode(root->right, value);
        }
    }
}

//Inorder traversal - print
void printTree_InorderTraversal(node *myNode) {
    if (myNode == nullptr) {
        cout << "Tree is empty";
        return;
    }
    stack<node *> myValue;
    node *temp = myNode;
    while (true) {
        if (temp != nullptr) {
            myValue.push(temp);
            temp = temp->left;
        } else {
            if (myValue.empty()) {
                break;
            }
            temp = myValue.top();
            cout << myValue.top()->data << " ";
            myValue.pop();
            temp = temp->right;
        }
    }
}

// by Post Order Traversal - save Value
void addValue_PostOrder_Traversal(vector<int> &value, node *myNode) {
    stack<node *> tempSave;
    stack<node *> forPrint;
    tempSave.push(myNode);
    while (!tempSave.empty()) {
        node *temp = tempSave.top();
        forPrint.push(temp);
        tempSave.pop();
        if (temp->left != nullptr && temp->right == nullptr) {
            tempSave.push(temp->left);
        } else if (temp->right != nullptr && temp->left == nullptr) {
            tempSave.push(temp->right);
        } else if (temp->right != nullptr && temp->left != nullptr) {
            tempSave.push(temp->left);
            tempSave.push(temp->right);
        }
    }
    while (!forPrint.empty()) {
        value.push_back(forPrint.top()->data);
        forPrint.pop();
    }
}


int main() {
    vector<int> value;
    node *myTree = new node(4);
    addNode(myTree, 3);
    addNode(myTree, 5);
    addNode(myTree, 6);
    addValue_PostOrder_Traversal(value, myTree);
    for (int i: value) {
        cout << i << " ";
    }
    delete myTree;
    return 0;
}
