#include <iostream>
#include <vector>

using namespace std;

struct node {
    int data;
    node *left;
    node *right;

    explicit node(int value) {
        data = value;
        left = nullptr;
        right = nullptr;
    }

    explicit node() {
        data = 0;
        left = nullptr;
        right = nullptr;
    }

    explicit node(int value, node *left, node *right) {
        data = value;
        this->left = left;
        this->right = right;
    }
};

void addValue(node *&myTree, int value) {
    if (myTree == nullptr) {
        myTree = new node(value);
    } else {
        if (value < myTree->data) {
            addValue(myTree->left, value);
        } else {
            addValue(myTree->right, value);
        }
    }
}

void valueOfTree(node *myTree, vector<int> &value) {
    if (myTree != nullptr) {
        valueOfTree(myTree->left, value);
        value.push_back(myTree->data);
        valueOfTree(myTree->right, value);
    }
}

void printTree_Inorder(const vector<int> &value) {
    if (value.empty()) {
        cout << "Tree is empty";
    } else {
        for (int i: value) {
            cout << i << " ";
        }
    }
}

void boundaryTraversal(node *myTree) {

}

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
