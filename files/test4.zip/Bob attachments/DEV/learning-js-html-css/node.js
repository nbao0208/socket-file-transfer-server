document.querySelector('h1').innerText = 'Hello, JavaScript!';
