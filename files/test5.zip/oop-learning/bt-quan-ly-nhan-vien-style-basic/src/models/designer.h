

#ifndef BT_QUAN_LY_NHAN_VIEN_STYLE_BASIC_DESIGNER_H
#define BT_QUAN_LY_NHAN_VIEN_STYLE_BASIC_DESIGNER_H

#include "staff.h"

class designer : public staff {
private:
    float bonus;
public:
    void setBonus();

    float calSalary();

    float getBonus() const;

};


#endif
