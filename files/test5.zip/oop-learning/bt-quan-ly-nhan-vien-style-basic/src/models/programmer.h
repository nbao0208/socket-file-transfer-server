

#ifndef BT_QUAN_LY_NHAN_VIEN_STYLE_BASIC_PROGRAMMER_H
#define BT_QUAN_LY_NHAN_VIEN_STYLE_BASIC_PROGRAMMER_H

#include "staff.h"

class programmer : public staff {
private:
    float overTime;
public:
    void setOverTime();

    float calSalary();

    float getOverTime() const;
};


#endif
