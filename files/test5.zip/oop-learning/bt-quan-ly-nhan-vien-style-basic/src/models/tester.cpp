#include <iostream>
#include "tester.h"

using namespace std;

int tester::getError() const {
    return error;
}

void tester::setError() {
    int error;
    cout << "Error: ";
    cin >> error;
    this->error = error;
}

float tester::calSalary() {
    return (5 * (this->salaryFactor)) + (0.2 * (this->error));
}


