

#ifndef BT_QUAN_LY_NHAN_VIEN_STYLE_BASIC_MANAGER_H
#define BT_QUAN_LY_NHAN_VIEN_STYLE_BASIC_MANAGER_H

#include "staff.h"

class manager : public staff {
public:
    float calSalary();
};


#endif
