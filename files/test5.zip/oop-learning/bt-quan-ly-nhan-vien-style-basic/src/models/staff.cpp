

#include "staff.h"

const string &staff::getName() const {
    return name;
}

void staff::setName(const string &name) {
    staff::name = name;
}

const string &staff::getDob() const {
    return dob;
}

void staff::setDob(const string &dob) {
    staff::dob = dob;
}

const string &staff::getId() const {
    return id;
}

void staff::setId(const string &id) {
    staff::id = id;
}

const string &staff::getAddress() const {
    return address;
}

void staff::setAddress(const string &address) {
    staff::address = address;
}

float staff::getSalaryFactor() const {
    return salaryFactor;
}

void staff::setSalaryFactor(float salaryFactor) {
    staff::salaryFactor = salaryFactor;
}

const string &staff::getStartedDay() const {
    return startedDay;
}

void staff::setStartedDay(const string &startedDay) {
    staff::startedDay = startedDay;
}

void staff::setAllInformation() {
    cout<<"Name: ";
    getline(cin, this->name);
    cout<<"Day of birth: ";
    getline(cin, this->dob);
    cout<<"ID: ";
    getline(cin, this->id);
    cout<<"Address: ";
    getline(cin, this->address);
    cout<<"The factor of your salary: ";
    cin>>this->salaryFactor;
    cin.ignore();
    cout<<"Starting day: ";
    getline(cin, this->startedDay);
}
