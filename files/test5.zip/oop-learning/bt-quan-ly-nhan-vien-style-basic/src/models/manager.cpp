

#include "manager.h"

float manager::calSalary() {
    return 10 * salaryFactor;
}