#include <iostream>
#include "models/manager.h"
#include "models/programmer.h"
#include "models/designer.h"
#include "models/tester.h"
#include <vector>
#include <memory>

using namespace std;

int main() {
    vector<staff *> employee;
    char answer = 'y';
    while (answer == 'y' || answer == 'Y') {
        int choice;
        cout << "Set the information for company's staff" << endl;
        cout << "1. Manager" << endl;
        cout << "2. Programmer" << endl;
        cout << "3. Designer" << endl;
        cout << "4. Tester" << endl;
        cout << "Type here: ";
        cin >> choice;
        cin.ignore();
        if (choice == 1) {
            staff *temporary = new manager();
            temporary->setAllInformation();
            employee.push_back(temporary);
//            delete temporary;
        } else if (choice == 2) {
            staff *temporary = new programmer();
            temporary->setAllInformation();
            temporary->setOverTime();
            employee.push_back(temporary);
//            delete temporary;
        } else if (choice == 3) {
            staff *temporary = new designer();
            temporary->setAllInformation();
            temporary->setBonus();
            employee.push_back(temporary);
//            delete temporary;
        } else if (choice == 4) {
            staff *temporary = new tester();
            temporary->setAllInformation();
            temporary->setError();
            employee.push_back(temporary);
//            delete temporary;
        } else {
            cout << "Don't exist this type of an employee" << endl;
        }
        cout << "Do you want to do again('y': yes or 'n': no): ";
        cin >> answer;
    }
    float sumSalary = 0;
    for (int i = 0; i < employee.size(); i++) {
        sumSalary += employee[i]->calSalary();
    }
    cout << "Total salary of all employees: " << sumSalary << " trieu dong";
//    for (int i = 0; i < employee.size(); i++) {
//        delete employee[i];
//    }
    return 0;
}
