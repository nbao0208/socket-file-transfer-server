//
// Created by Bao Nguyen on 03/10/2023.
//

#ifndef BT_QUAN_LY_NHAN_VIEN_MYMANAGERINFORMATION_H
#define BT_QUAN_LY_NHAN_VIEN_MYMANAGERINFORMATION_H

#include "../models/personnel/staff.h"
#include "../services/addInfo.h"
#include <vector>

void myManagerInformation(vector<staff *> &personnel, addInfo addInfo);

#endif //BT_QUAN_LY_NHAN_VIEN_MYMANAGERINFORMATION_H
