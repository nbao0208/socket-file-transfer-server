

#ifndef BT_QUAN_LY_NHAN_VIEN_MYTESTERINFORMATION_H
#define BT_QUAN_LY_NHAN_VIEN_MYTESTERINFORMATION_H

#include "../models/personnel/staff.h"
#include "../services/addInfo.h"
#include <vector>

void myTesterInformation(vector<staff *> &personnel, addInfo addInfo);

#endif
