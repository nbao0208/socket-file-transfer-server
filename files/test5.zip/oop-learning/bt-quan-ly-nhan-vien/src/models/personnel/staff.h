

#ifndef BT_QUAN_LY_NHAN_VIEN_STAFF_H
#define BT_QUAN_LY_NHAN_VIEN_STAFF_H

#include <string>

using namespace std;

class staff {
protected:
    string name;
    string id;
    string dob;
    string address;
    float heSoLuong;
    string startedDay;
public:
    const string &getName() const;

    void setName(const string &name);

    const string &getId() const;

    void setId(const string &id);

    const string &getDob() const;

    void setDob(const string &dob);

    const string &getAddress() const;

    void setAddress(const string &address);

    float getHeSoLuong() const;

    void setHeSoLuong(float heSoLuong);

    const string &getStartedDay() const;

    void setStartedDay(const string &startedDay);

    virtual float calSalary() = 0;
};


#endif \
