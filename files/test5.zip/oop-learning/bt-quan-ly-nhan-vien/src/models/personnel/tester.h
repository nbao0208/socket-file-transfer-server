

#ifndef BT_QUAN_LY_NHAN_VIEN_TESTER_H
#define BT_QUAN_LY_NHAN_VIEN_TESTER_H

#include "staff.h"

class tester : public staff {
private:
    int error;
public:
    int getError() const;

    void setError(int error);

    float calSalary();
};


#endif //BT_QUAN_LY_NHAN_VIEN_TESTER_H
