
#ifndef BT_QUAN_LY_NHAN_VIEN_PROGRAMMER_H
#define BT_QUAN_LY_NHAN_VIEN_PROGRAMMER_H

#include "staff.h"

using namespace std;

class programmer : public staff {
private:
    float overTime;
public:
    float getOverTime() const;

    void setOverTime(float overTime);

    float calSalary();
};


#endif
