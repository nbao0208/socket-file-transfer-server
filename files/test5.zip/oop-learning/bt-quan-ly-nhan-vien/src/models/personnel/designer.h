
#ifndef BT_QUAN_LY_NHAN_VIEN_DESIGNER_H
#define BT_QUAN_LY_NHAN_VIEN_DESIGNER_H

#include "staff.h"

class designer : public staff {
private:
    float bonus;
public:
    float getBonus() const;

    void setBonus(float bonus);

    float calSalary();
};


#endif //BT_QUAN_LY_NHAN_VIEN_DESIGNER_H
