

#ifndef BT_QUAN_LY_NHAN_VIEN_MANAGER_H
#define BT_QUAN_LY_NHAN_VIEN_MANAGER_H

#include "staff.h"

using namespace std;

class manager : public staff {
public:
    float calSalary();
};


#endif
