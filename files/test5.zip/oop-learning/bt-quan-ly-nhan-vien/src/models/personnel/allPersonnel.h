

#ifndef BT_QUAN_LY_NHAN_VIEN_ALLPERSONNEL_H
#define BT_QUAN_LY_NHAN_VIEN_ALLPERSONNEL_H

#include "manager.h"
#include "designer.h"
#include "programmer.h"
#include "tester.h"


#endif
