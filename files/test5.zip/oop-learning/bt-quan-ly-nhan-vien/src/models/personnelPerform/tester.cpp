//
// Created by Bao Nguyen on 02/10/2023.
//

#include "../personnel/tester.h"

int tester::getError() const {
    return error;
}

void tester::setError(int error) {
    tester::error = error;
}

float tester::calSalary() {
    return (5*heSoLuong) + (error*0.2);
}

