//
// Created by Bao Nguyen on 02/10/2023.
//

#include "../personnel/staff.h"

const string &staff::getName() const {
    return name;
}

void staff::setName(const string &name) {
    staff::name = name;
}

const string &staff::getId() const {
    return id;
}

void staff::setId(const string &id) {
    staff::id = id;
}

const string &staff::getDob() const {
    return dob;
}

void staff::setDob(const string &dob) {
    staff::dob = dob;
}

const string &staff::getAddress() const {
    return address;
}

void staff::setAddress(const string &address) {
    staff::address = address;
}

float staff::getHeSoLuong() const {
    return heSoLuong;
}

void staff::setHeSoLuong(float heSoLuong) {
    staff::heSoLuong = heSoLuong;
}

const string &staff::getStartedDay() const {
    return startedDay;
}

void staff::setStartedDay(const string &startedDay) {
    staff::startedDay = startedDay;
}
