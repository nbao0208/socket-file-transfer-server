

#include "../personnel/manager.h"
using namespace std;

float manager::calSalary() {
    return 10*heSoLuong;
}