//
// Created by Bao Nguyen on 02/10/2023.
//

#include "../personnel/designer.h"

float designer::getBonus() const {
    return bonus;
}

void designer::setBonus(float bonus) {
    designer::bonus = bonus;
}

float designer::calSalary() {
    return (6*heSoLuong) + bonus;
}
