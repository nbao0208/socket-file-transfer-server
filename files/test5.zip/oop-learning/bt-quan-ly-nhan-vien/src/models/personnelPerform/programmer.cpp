

#include "../personnel/programmer.h"

float programmer::getOverTime() const {
    return overTime;
}

void programmer::setOverTime(float overTime) {
    programmer::overTime = overTime;
}

float programmer::calSalary() {
    return (7*heSoLuong) + (overTime*0.1);
}
