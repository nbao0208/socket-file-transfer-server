#include "../lib/saveInformation.h"
#include <iostream>

using namespace std;

void saveInfo(string &name, string &id, string &dob, string &address, float &heSoLuong, string &startedDay) {
    cout << "Name: ";
    getline(cin, name);
    cout << "Day of birth: ";
    getline(cin, dob);
    cout << "ID: ";
    getline(cin, id);
    cout << "Address: ";
    getline(cin, address);
    cout << "He so luong: ";
    cin >> heSoLuong;
    cin.ignore();
    cout << "Started Day: ";
    getline(cin, startedDay);
}
