#include "../lib/myProgrammerInformation.h"
#include <iostream>
#include "../lib/saveInformation.h"

using namespace std;

void myProgrammerInformation(vector<staff *> &personnel, addInfo addInfo) {
    string name;
    string id;
    string dob;
    string address;
    float heSoLuong;
    string startedDay;
    float overTime;
    saveInfo(name, id, dob, address, heSoLuong, startedDay);
    cout << "Overtime: ";
    cin >> overTime;
    staff *temporary;
    temporary = new programmer;
    *temporary = addInfo.createProgrammer(name, id, dob, address, heSoLuong, startedDay, overTime);
    personnel.push_back(temporary);
}