#include "../lib/myManagerInformation.h"
#include <iostream>
#include "../lib/saveInformation.h"

using namespace std;

void myManagerInformation(vector<staff *> &personnel, addInfo addInfo) {
    string name;
    string id;
    string dob;
    string address;
    float heSoLuong;
    string startedDay;
    saveInfo(name, id, dob, address, heSoLuong, startedDay);
    staff *temporary;
    temporary = new manager;
    *temporary = addInfo.createManager(name, id, dob, address, heSoLuong, startedDay);
    personnel.push_back(temporary);
}