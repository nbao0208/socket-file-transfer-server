#include "../lib/theSystem.h"
#include <iostream>
#include "../lib/myManagerInformation.h"
#include "../lib/myTesterInformation.h"
#include "../lib/myProgrammerInformation.h"
#include "../lib/myDesignerInformation.h"

using namespace std;

void mySystem(vector<staff *> &personnel) {
    addInfo addInfo;
    char ans = 'y';
    while (ans == 'y') {
        int choice;
        cout << "What part of staff you want to save information" << endl;
        cout << "1. Manager" << endl;
        cout << "2. Programmer" << endl;
        cout << "3. Designer" << endl;
        cout << "4. Tester" << endl;
        cout << "Type here: ";
        cin >> choice;
        cin.ignore();
        if (choice == 1) {
            myManagerInformation(personnel, addInfo);
        } else if (choice == 2) {
            myProgrammerInformation(personnel, addInfo);
        } else if (choice == 3) {
            myDesignerInformation(personnel, addInfo);
        } else if (choice == 4) {
            myTesterInformation(personnel, addInfo);
        } else {
            cout << "DON'T EXIST" << endl;
        }
        cout << "Do you want to do again('y' for yes and 'n' for no): ";
        cin >> ans;
    }
}