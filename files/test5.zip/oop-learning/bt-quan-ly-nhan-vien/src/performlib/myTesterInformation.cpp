#include "../lib/myTesterInformation.h"
#include <iostream>
#include "../lib/saveInformation.h"

using namespace std;

void myTesterInformation(vector<staff *> &personnel, addInfo addInfo) {
    string name;
    string id;
    string dob;
    string address;
    float heSoLuong;
    string startedDay;
    int error;
    saveInfo(name, id, dob, address, heSoLuong, startedDay);
    cout << "Error found: ";
    cin >> error;
    staff *temporary = new tester;
    *temporary = addInfo.createTester(name, id, dob, address, heSoLuong, startedDay, error);
    personnel.push_back(temporary);
}