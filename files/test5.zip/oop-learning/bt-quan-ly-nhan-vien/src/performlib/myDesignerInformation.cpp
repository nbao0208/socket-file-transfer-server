#include "../lib/myDesignerInformation.h"
#include <iostream>
#include "../lib/saveInformation.h"

using namespace std;

void myDesignerInformation(vector<staff *> &personnel, addInfo addInfo) {
    string name;
    string id;
    string dob;
    string address;
    float heSoLuong;
    string startedDay;
    float bonus;
    saveInfo(name, id, dob, address, heSoLuong, startedDay);
    cout << "Bonus: ";
    cin >> bonus;
    staff *temporary;
    temporary = new designer;
    *temporary = addInfo.createDesigner(name, id, dob, address, heSoLuong, startedDay, bonus);
    personnel.push_back(temporary);
}